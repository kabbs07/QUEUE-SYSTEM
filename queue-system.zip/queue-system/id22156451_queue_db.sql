-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 19, 2024 at 06:55 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id22156451_queue_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cashier`
--

CREATE TABLE `cashier` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `log_status` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cashier`
--

INSERT INTO `cashier` (`id`, `name`, `log_status`, `status`, `password`) VALUES
(73, 'C1', 0, 1, '$2y$10$lBvV.enqie8cj6c9uCOCF.6TwUdcCxktRgHPMsjqlG99zCTgGO3MC'),
(74, 'C2', 0, 1, '$2y$10$b1NPbmD9oGCkxHCRYRoUz.VTjL0Z5mHDNqxK/FnM4A3W/aRm8laUS'),
(75, 'C3', 0, 1, '$2y$10$LyOkep9KN4KlnW1bbKH5M.5Pw1QR4TafwFP2GIa3Yg.2DLJB2Iy9.');

-- --------------------------------------------------------

--
-- Table structure for table `priority_queue`
--

CREATE TABLE `priority_queue` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `student_number` varchar(255) NOT NULL,
  `service_type` varchar(255) NOT NULL,
  `payment_for` varchar(255) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `queue_number` varchar(255) NOT NULL,
  `queue_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL,
  `cashierid` int(11) DEFAULT NULL,
  `start_service_time` datetime DEFAULT NULL,
  `end_service_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `regular_queue`
--

CREATE TABLE `regular_queue` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `student_number` varchar(255) NOT NULL,
  `service_type` varchar(255) NOT NULL,
  `payment_for` varchar(255) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `queue_number` varchar(255) NOT NULL,
  `queue_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL,
  `cashierid` int(11) DEFAULT NULL,
  `start_service_time` datetime DEFAULT NULL,
  `end_service_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_options`
--

CREATE TABLE `transaction_options` (
  `id` int(11) NOT NULL,
  `option_type` enum('customer','service','payment_for','payment_mode') NOT NULL,
  `option_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_options`
--

INSERT INTO `transaction_options` (`id`, `option_type`, `option_name`) VALUES
(164, 'service', 'Payment'),
(165, 'payment_mode', 'Cash'),
(166, 'payment_mode', 'Credit / Debit'),
(168, 'payment_mode', 'Online Payment (e.g Gcash)'),
(177, 'payment_for', 'Tuition'),
(178, 'payment_for', 'Books & Uniforms'),
(212, 'customer', 'Regular (Student, Parent, Visitor, etc)'),
(213, 'customer', 'Priority (Senior, Pregnant, PWD)'),
(215, 'payment_mode', 'N/A (for Claiming of Receipt)'),
(218, 'service', 'Claiming of Receipt'),
(226, 'customer', 'Claiming of Receipt Only'),
(227, 'payment_for', 'Payment for Photocopying/Library'),
(228, 'payment_for', 'Laboratory Fees'),
(229, 'payment_for', 'N/A (for Claiming of Receipt)');

-- --------------------------------------------------------

--
-- Table structure for table `userss`
--

CREATE TABLE `userss` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userss`
--

INSERT INTO `userss` (`id`, `name`, `username`, `password`) VALUES
(18, 'Admin1', 'Admin', '$2y$10$q2H.NuqD9PCESzqXVlJwQO/9tb2/IQGvFYhQOifmkLoR7/JZDSxfq');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cashier`
--
ALTER TABLE `cashier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priority_queue`
--
ALTER TABLE `priority_queue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cashier_id` (`cashierid`);

--
-- Indexes for table `regular_queue`
--
ALTER TABLE `regular_queue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cashier_id` (`cashierid`);

--
-- Indexes for table `transaction_options`
--
ALTER TABLE `transaction_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userss`
--
ALTER TABLE `userss`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cashier`
--
ALTER TABLE `cashier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `priority_queue`
--
ALTER TABLE `priority_queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `regular_queue`
--
ALTER TABLE `regular_queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `transaction_options`
--
ALTER TABLE `transaction_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=230;

--
-- AUTO_INCREMENT for table `userss`
--
ALTER TABLE `userss`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `priority_queue`
--
ALTER TABLE `priority_queue`
  ADD CONSTRAINT `priority_queue_ibfk_1` FOREIGN KEY (`cashierid`) REFERENCES `cashier` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `regular_queue`
--
ALTER TABLE `regular_queue`
  ADD CONSTRAINT `regular_queue_ibfk_1` FOREIGN KEY (`cashierid`) REFERENCES `cashier` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
