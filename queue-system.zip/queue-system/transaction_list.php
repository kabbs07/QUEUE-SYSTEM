<?php
session_start();

// Include your database connection code here
include 'db_connection.php';



if (isset($_POST['add_customer_option'])) {
    $typeOfCustomer = $_POST['typeOfCustomer'];

    // Sanitize the input to prevent SQL injection (you can use prepared statements for better security)
    $typeOfCustomer = mysqli_real_escape_string($conn, $typeOfCustomer);

    // Insert the option into the database
    $sql = "INSERT INTO transaction_options (option_name, option_type) VALUES ('$typeOfCustomer', 'customer')";

    if ($conn->query($sql) === TRUE) {
        // Option added successfully
        echo '<script>alert("Option added successfully!"); window.location.href = "transaction_list.php";</script>';    
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
if (isset($_POST['add_service_option'])) {
    $typeOfService = $_POST['typeOfService'];

    // Sanitize the input to prevent SQL injection (you can use prepared statements for better security)
    $typeOfService = mysqli_real_escape_string($conn, $typeOfService);

    // Insert the option into the database
    $sql = "INSERT INTO transaction_options (option_name, option_type) VALUES ('$typeOfService', 'service')";

    if ($conn->query($sql) === TRUE) {
        // Option added successfully
        echo '<script>alert("Option added successfully!"); window.location.href = "transaction_list.php";</script>';    
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
if (isset($_POST['add_payment_option'])) {
    $paymentFor = $_POST['paymentFor'];

    // Sanitize the input to prevent SQL injection (you can use prepared statements for better security)
    $paymentFor = mysqli_real_escape_string($conn, $paymentFor);

    // Insert the option into the database
    $sql = "INSERT INTO transaction_options (option_name, option_type) VALUES ('$paymentFor', 'payment_for')";

    if ($conn->query($sql) === TRUE) {
        // Option added successfully
        echo '<script>alert("Option added successfully!"); window.location.href = "transaction_list.php";</script>';    
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
if (isset($_POST['add_mode_option'])) {
    $modeOfPayment = $_POST['modeOfPayment'];

    // Sanitize the input to prevent SQL injection (you can use prepared statements for better security)
    $modeOfPayment = mysqli_real_escape_string($conn, $modeOfPayment);

    // Insert the option into the database
    $sql = "INSERT INTO transaction_options (option_name, option_type) VALUES ('$modeOfPayment', 'payment_mode')";

    if ($conn->query($sql) === TRUE) {
        // Option added successfully
        echo '<script>alert("Option added successfully!"); window.location.href = "transaction_list.php";</script>';    
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="admin2.css">
    <link rel="icon" href="sdcafafa.jpg">
    <title>Admin Dashboard</title>
</head>
<body>

<?php include 'admin_navbar.php'?>


<div class="alert alert-success" id="successAlert" style="display: none;">
    Option added successfully.
</div>


<div class="container mt-4">
    <h2 class="text-center mb-4 mt-3">Transaction Management</h2> 
    <div class="row">
        <!-- First column -->
        <div class="col-md-6">
            <form action="transaction_list.php" method="post">
                <div class="form-group">
            <label for="typeOfCustomer"><i class="fas fa-user-tag"></i> Customer Type</label>
            <input type="text" class="form-control" id="typeOfCustomer" name="typeOfCustomer" placeholder="Enter customer type" required>
            <button class="btn btn-primary mt-2" type="submit" name="add_customer_option">Add Option</button>
            <button class="btn btn-success mt-2" type="button" id="viewCustomerOptionsBtn">View Options</button>        </div>
            </form>
            <form action="transaction_list.php" method="post">
            <div class="form-group">
                    <label for="typeOfService"><i class="fas fa-concierge-bell"></i> Service Type</label>
                    <input type="text" class="form-control" id="typeOfService" name="typeOfService" placeholder="Enter service type" required>
                    <button class="btn btn-primary mt-2" type="submit" name="add_service_option">Add Option</button>
                    <button class="btn btn-success mt-2" type="button" id="viewServiceOptionsBtn">View Options</button>                </div>
            </form>
                
        </div>

        <!-- Second column -->
        <div class="col-md-6">
        <form action="transaction_list.php" method="post">
                <div class="form-group">
                    <label for="paymentFor"><i class="fas fa-money-bill-wave"></i> Payment For</label>
                    <input type="text" class="form-control" id="paymentFor" name="paymentFor" placeholder="Enter payment for" required>
                    <button class="btn btn-primary mt-2" type="submit" name="add_payment_option">Add Option</button>

                    <button class="btn btn-success mt-2" type="button" id="viewPaymentOptionsBtn">View Options</button>                </div>
                    </form>
                    <form action="transaction_list.php" method="post">
                    <div class="form-group">
                    <label for="modeOfPayment"><i class="fas fa-credit-card"></i> Payment Mode</label>
                    <input type="text" class="form-control" id="modeOfPayment" name="modeOfPayment" placeholder="Enter payment mode" required>
                    <button class="btn btn-primary mt-2" type="submit" name="add_mode_option">Add Option</button>
                    <button class="btn btn-success mt-2" type="button" id="viewPaymentModeOptionsBtn">View Options</button>
                </div>
                    </form>
              
        </div>
    </div>
</div>

<!-- MODAL -->
<div class="modal fade" id="customerOptionsModal" tabindex="-1" role="dialog" aria-labelledby="customerOptionsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="customerOptionsModalLabel">Customer Type Options</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Display the options here using PHP to fetch data from the database -->
                <ul class="list-group">
                    <?php
                        $customerOptionsSql = "SELECT id, option_name FROM transaction_options WHERE option_type = 'customer'";
                        $customerOptionsResult = $conn->query($customerOptionsSql);
                        if ($customerOptionsResult->num_rows > 0) {
                            while ($row = $customerOptionsResult->fetch_assoc()) {
                                echo "<li class='list-group-item d-flex justify-content-between align-items-center'>" . $row['option_name'] . "<button class='btn btn-danger btn-sm' onclick='deleteOption(" . $row['id'] . ")'>Delete</button></li>";
                            }
                        } else {
                            echo "<li class='list-group-item'>No options available.</li>";
                        }
                    ?>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Type of Service Options -->
<div class="modal fade" id="serviceOptionsModal" tabindex="-1" role="dialog" aria-labelledby="serviceOptionsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="serviceOptionsModalLabel">Service Type Options</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Display the options here using PHP to fetch data from the database -->
                <ul class="list-group">
                    <?php
                        $serviceOptionsSql = "SELECT id, option_name FROM transaction_options WHERE option_type = 'service'";
                        $serviceOptionsResult = $conn->query($serviceOptionsSql);
                        if ($serviceOptionsResult->num_rows > 0) {
                            while ($row = $serviceOptionsResult->fetch_assoc()) {
                                echo "<li class='list-group-item d-flex justify-content-between align-items-center'>" . $row['option_name'] . "<button class='btn btn-danger btn-sm' onclick='deleteOption(" . $row['id'] . ")'>Delete</button></li>";
                            }
                        } else {
                            echo "<li class='list-group-item'>No options available.</li>";
                        }
                    ?>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Payment For Options -->
<div class="modal fade" id="paymentForOptionsModal" tabindex="-1" role="dialog" aria-labelledby="paymentForOptionsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="paymentForOptionsModalLabel">Payment For Options</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Display the options here using PHP to fetch data from the database -->
                <ul class="list-group">
                    <?php
                        $paymentForOptionsSql = "SELECT id, option_name FROM transaction_options WHERE option_type = 'payment_for'";
                        $paymentForOptionsResult = $conn->query($paymentForOptionsSql);
                        if ($paymentForOptionsResult->num_rows > 0) {
                            while ($row = $paymentForOptionsResult->fetch_assoc()) {
                                echo "<li class='list-group-item d-flex justify-content-between align-items-center'>" . $row['option_name'] . "<button class='btn btn-danger btn-sm' onclick='deleteOption(" . $row['id'] . ")'>Delete</button></li>";
                            }
                        } else {
                            echo "<li class='list-group-item'>No options available.</li>";
                        }
                    ?>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Mode of Payment Options -->
<div class="modal fade" id="paymentModeOptionsModal" tabindex="-1" role="dialog" aria-labelledby="paymentModeOptionsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="paymentModeOptionsModalLabel">Payment Mode Options</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Display the options here using PHP to fetch data from the database -->
                <ul class="list-group">
                    <?php
                        $paymentModeOptionsSql = "SELECT id, option_name FROM transaction_options WHERE option_type = 'payment_mode'";
                        $paymentModeOptionsResult = $conn->query($paymentModeOptionsSql);
                        if ($paymentModeOptionsResult->num_rows > 0) {
                            while ($row = $paymentModeOptionsResult->fetch_assoc()) {
                                echo "<li class='list-group-item d-flex justify-content-between align-items-center'>" . $row['option_name'] . "<button class='btn btn-danger btn-sm' onclick='deleteOption(" . $row['id'] . ")'>Delete</button></li>";
                            }
                        } else {
                            echo "<li class='list-group-item'>No options available.</li>";
                        }
                    ?>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script>
function deleteOption(optionId) {
    console.log("Deleting option with ID: " + optionId); // Debugging statement

    if (confirm("Are you sure you want to delete this option?")) {
        $.ajax({
            type: "POST",
            url: "delete_option.php",
            data: { id: optionId },
            success: function (response) {
                console.log("Server response: " + response); // Debugging statement
                if (response === 'success') {
                    // Refresh the modal content after successful deletion
                    $("#customerOptionsModal .modal-body").load(location.href + " #customerOptionsModal .modal-body");
                    $("#serviceOptionsModal .modal-body").load(location.href + " #serviceOptionsModal .modal-body");
                    $("#paymentForOptionsModal .modal-body").load(location.href + " #paymentForOptionsModal .modal-body");
                    $("#paymentModeOptionsModal .modal-body").load(location.href + " #paymentModeOptionsModal .modal-body");
                } else {
                    alert("Error deleting option.");
                }
            }
        });
    }
}



    $(document).ready(function () {
        $("#viewCustomerOptionsBtn").click(function () {
            $("#customerOptionsModal").modal('show');
        });
    });
        $(document).ready(function () {
        $("#viewServiceOptionsBtn").click(function () {
            $("#serviceOptionsModal").modal('show');
        });
    });
    $(document).ready(function () {
        $("#viewPaymentOptionsBtn").click(function () {
            $("#paymentForOptionsModal").modal('show');
        });
    });
    $(document).ready(function () {
        $("#viewPaymentModeOptionsBtn").click(function () {
            $("#paymentModeOptionsModal").modal('show');
        });
    });

</script>





</body>
</html>
