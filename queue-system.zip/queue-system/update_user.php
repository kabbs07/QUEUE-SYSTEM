<?php
session_start();

// Include your database connection file
include_once 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the form data and update the user in the database

    $userId = isset($_POST['userId']) ? $_POST['userId'] : "";
    $newUsername = isset($_POST['newUsername']) ? $_POST['newUsername'] : "";
    $newPassword = isset($_POST['newPassword']) ? password_hash($_POST['newPassword'], PASSWORD_DEFAULT) : "";

    // Validate and update the user in the database
    if (!empty($userId) && !empty($newUsername)) {
        $updateSql = "UPDATE userss SET username = '$newUsername', password = '$newPassword' WHERE id = $userId";

        if ($conn->query($updateSql) === TRUE) {
            // Redirect to the user management page or wherever you want after updating
            header("Location: users.php");
            exit();
        } else {
            // Handle the error, if any
            echo "Error updating record: " . $conn->error;
        }
    }
}

// Close the database connection
$conn->close();
?>
