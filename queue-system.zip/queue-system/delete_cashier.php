<?php
include_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) ? $_POST['id'] : 0;

    // Implement your logic to delete the cashier with the specified ID
    $sql = "DELETE FROM cashier WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo 'success';
    } else {
        echo 'Error deleting cashier.';
    }

    $stmt->close();
    $conn->close();
}
?>
