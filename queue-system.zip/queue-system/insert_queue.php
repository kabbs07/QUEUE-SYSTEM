<?php
include 'db_connection.php';

// Get selected options from the POST data
$name = $_POST['name'];
$studentNumber = $_POST['studentNumber'];
$selectedCustomer = $_POST['selectedCustomer'];
$selectedService = $_POST['selectedService'];
$selectedPaymentFor = $_POST['selectedPaymentFor'];
$selectedPaymentMode = $_POST['selectedPaymentMode'];
$email = $_POST['email'];

// Determine the queue table based on the customer type
$queueTable = ($selectedCustomer === 'Priority (Senior, Pregnant, PWD)') ? 'priority_queue' : 'regular_queue';

// Get the last inserted queue number and timestamp from the database
$getLastQueueInfoQuery = "SELECT queue_number, queue_time FROM $queueTable ORDER BY id DESC LIMIT 1";
$lastQueueInfoResult = $conn->query($getLastQueueInfoQuery);

if ($lastQueueInfoResult->num_rows > 0) {
    $lastQueueInfo = $lastQueueInfoResult->fetch_assoc();
    $lastQueueNumber = $lastQueueInfo['queue_number'];
    $lastQueueTime = $lastQueueInfo['queue_time'];
    $currentDate = date('Y-m-d');

    // Check if the current date is different from the stored date
    if ($currentDate > date('Y-m-d', strtotime($lastQueueTime))) {
        // If different, reset the numeric part to '000'
        $nextNumericPart = '000';
    } else {
        // Extract the numeric part and increment by 1
        $numericPart = (int)filter_var($lastQueueNumber, FILTER_SANITIZE_NUMBER_INT);
        $nextNumericPart = sprintf('%03d', $numericPart + 1);
    }
} else {
    // If no previous entries, start from '000'
    $nextNumericPart = '000';
}

// Create the queue number
$firstLetter = strtoupper(substr($selectedCustomer, 0, 1));
$queueNumber = $firstLetter . $nextNumericPart;

// Insert selected options into the appropriate queue table
$insertQuery = "INSERT INTO $queueTable (name, student_number, service_type, payment_for, payment_mode, email, queue_number, queue_time, status) 
                VALUES ('$name', '$studentNumber', '$selectedService', '$selectedPaymentFor', '$selectedPaymentMode', '$email', '$queueNumber', NOW(), 'pending')";
$result = $conn->query($insertQuery);

// Initialize response array
$response = [];

if ($result) {
    // Calculate the average service time
    $averageServiceTimeQuery = "SELECT AVG(TIMESTAMPDIFF(SECOND, start_service_time, end_service_time)) / 60 AS average_service_time_minutes
                                FROM $queueTable
                                WHERE status = 'served'";

    // Execute the query to calculate the average service time
    $averageServiceTimeResult = $conn->query($averageServiceTimeQuery);

    // Fetch the average service time and add it to the response
    if ($averageServiceTimeResult && $row = $averageServiceTimeResult->fetch_assoc()) {
        $response['average_service_time'] = floatval($row['average_service_time_minutes']);
    } else {
        $response['average_service_time'] = null; // If there's an error, set it to null
    }

    // Add the queue number to the response
    $response['success'] = true;
    $response['queueNumber'] = $queueNumber;
} else {
    // Handle insert error
    $response['success'] = false;
    $response['error'] = 'Failed to insert data into the database';
}

// Close the database connection
$conn->close();

// Encode and return the response as JSON
echo json_encode($response);
?>
