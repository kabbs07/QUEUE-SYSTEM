<?php
// Include PHPMailer autoloader
require 'vendor/autoload.php';

// Check if the email parameter is set
if (isset($_POST['email'])) {
    // Sanitize and validate the email address
    $customerEmail = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    // Create a new PHPMailer instance
    $mail = new PHPMailer\PHPMailer\PHPMailer();

    // SMTP configuration (adjust as needed)
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // Your SMTP host
    $mail->SMTPAuth = true;
    $mail->Username = 'alfonsomarcus778@gmail.com'; // Your SMTP username
    $mail->Password = 'lqnv vtfw fgdx werk'; // Your SMTP password
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587; // Your SMTP port

    // Set sender and recipient
    $mail->setFrom('alfonsomarcus778@gmail.com', 'Queue Ease'); // Sender's email and name
    $mail->addAddress($customerEmail); // Recipient's email

    // Set email subject
    $mail->Subject = 'Notification: Your Appointment';

    // HTML email body
    $mail->isHTML(true);
    $mail->Body = '
        <html>
        <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                    background-color: #f8f8f8;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                }
                h1 {
                    color: #333;
                }
                p {
                    color: #555;
                }
                .logo {
                    max-width: 100px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <a href="https://imgbb.com/"><img src="https://i.ibb.co/BjK9sg2/logo-header.png" alt="logo-header" border="0"></a>
                <h1>Notification: Your Appointment</h1>
                <p>Dear Customer,</p>
                <p>We regret to inform you that you missed your queue. Please contact us to reschedule.</p>
                <p>Thank you.</p>
            </div>
        </body>
        </html>
    ';

    // Attempt to send the email
    if ($mail->send()) {
        // Email sent successfully, return success response
        echo json_encode(array('status' => 'success', 'message' => 'Email sent successfully.'));
    } else {
        // Failed to send email, return error response
        echo json_encode(array('status' => 'error', 'message' => 'Failed to send email. Error: ' . $mail->ErrorInfo));
    }
} else {
    // If the email parameter is not set, return an error message
    echo json_encode(array('status' => 'error', 'message' => 'Email parameter is missing.'));
}
?>
