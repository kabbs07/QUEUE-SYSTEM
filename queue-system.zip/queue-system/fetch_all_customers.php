<?php
include_once 'db_connection.php';

// Query to fetch all customer data from priority_queue and regular_queue
$sql = "SELECT q.name, q.student_number, q.service_type, q.payment_for, q.payment_mode, q.email, q.queue_number, q.queue_time, q.status, c.name AS cashier_name
        FROM (SELECT * FROM priority_queue
              UNION ALL
              SELECT * FROM regular_queue) AS q
        LEFT JOIN cashier AS c ON q.cashierid = c.id
        ORDER BY q.queue_time ASC";

$result = $conn->query($sql);

$response = [];

// Fetch data and add it to the response
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $response[] = $row;
    }
}

// Close the database connection
$conn->close();

// Return the data as JSON
echo json_encode($response);
?>
