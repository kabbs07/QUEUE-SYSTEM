<?php
session_start();

// Include your database connection file
include_once 'db_connection.php';

// Initialize variables for messages and errors
$error_message = "";
$success_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the registration form data

    // Get form data
    $name = isset($_POST['name']) ? $_POST['name'] : "";
    $username = isset($_POST['username']) ? $_POST['username'] : "";
    $password = isset($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : "";

    // Check if the username already exists
    $check_username_query = "SELECT * FROM userss WHERE username = '$username'";
    $check_username_result = $conn->query($check_username_query);

    if ($check_username_result->num_rows > 0) {
        $error_message = "Username '$username' already exists. Please choose a different username.";
    } else {
        // Insert data into the database
        $sql = "INSERT INTO userss (name, username, password) VALUES ('$name', '$username', '$password')";

        if ($conn->query($sql) === TRUE) {
            $success_message = "Registration successful! You can now log in.";
        } else {
            $error_message = "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Close the database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Result</title>
</head>
<body>

<?php
// Display success or error message
if (!empty($success_message)) {
    echo '<p style="color: green;">' . $success_message . '</p>';
} elseif (!empty($error_message)) {
    echo '<p style="color: red;">' . $error_message . '</p>';
}
?>

<a href="test2.php">Go back to registration</a>

</body>
</html>
