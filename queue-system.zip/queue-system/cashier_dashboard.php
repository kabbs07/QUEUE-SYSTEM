<?php
session_start();
include_once 'db_connection.php';

function updateLogStatus($userId, $logStatus) {
    global $conn;

    $logStatusNumeric = ($logStatus === 'in use') ? 1 : 0;

    $sql = "UPDATE cashier SET log_status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $logStatusNumeric, $userId);
    $stmt->execute();

    if ($stmt->error) {
        echo "Error updating log status: " . $stmt->error;
    }

    $stmt->close();
}

if (!isset($_SESSION['cashier_id'])) {
    header("Location: cashier_login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['logout'])) {
    updateLogStatus($_SESSION['cashier_id'], 'not in use');
    session_unset();
    session_destroy();
    header("Location: cashier_login.php");
    exit();
}

$cashierId = $_SESSION['cashier_id']; // Retrieve cashier_id from session
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Cashier Dashboard</title>
    <link rel="icon" href="sdcafafa.jpg">
    <style>
        body {
            background-color: #f8f9fa;
            text-decoration:none;
        }
        .container-fluid {
            margin-top: 20px;
        }
        .navbar {
            background-color: #CD0B0B;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff;
        }
        .navbar-brand i {
            margin-right: 5px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .card-body {
            padding: 20px;
        }
        .queue-info {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
        }
        .icon {
            font-size: 48px;
        }
        .btn-action {
            width: 100%;
            margin-top: 5px;
            font-size: 12px;
        }
        .btn-no-show {
            width: 100%;
            margin-top: 5px;
            font-size: 12px;
            background-color: #dc3545; /* Red color for no-show button */
            border-color: #dc3545;
        }
        .details-card {
            margin-top: 20px;
        }
           .openDisplayBtn{
            text-decoration:none;
            background-color:#CD0B0B;
            color:white;
            font-weight:500;
            transition:all ease-in-out 250ms;
            outline:none !important;
        }
        .openDisplayBtn:hover{
            text-decoration:none;
            color:white;
            opacity:0.7;
            
        }
       
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="#"><i class="fas fa-cash-register"></i> Cashier Dashboard</a>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <?php
            // Check if the 'cashier_name' session variable is set
            if (isset($_SESSION['cashier_name'])) {
                echo '<a class="nav-link" href="#">Welcome, ' . $_SESSION['cashier_name'] . ' <i class="fas fa-user"></i></a>';
            } else {
                // Handle the case where the session variable is not set
                echo '<a class="nav-link" href="#">Welcome, Guest <i class="fas fa-user"></i></a>';
            }
            ?>
        </li>
        <li class="nav-item">
            <!-- Logout Form -->
            <form action="cashier_dashboard.php" method="post">
                <button type="submit" name="logout" class="nav-link btn btn-link">Logout <i class="fas fa-sign-out-alt"></i></button>
            </form>
        </li>
    </ul>
</nav>

<div class="container-fluid">
    <div class="text-center mb-4">
    <div class="d-grid gap-1 d-md-block ms-auto">
  <a href="Monitor1.php" target="_blank"class="openDisplayBtn btn">Open Customer Display</a>
  <a href="get_queue_page.php"target="blank" class="openDisplayBtn btn">Open Queue Registration Page</a>
</div>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div class="queue-info">
                        <i class="fas fa-users icon"></i>
                        <p>Current Queue: <span id="currentQueueNumber"></span></p>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <button id="serveNextBtn" class="btn btn-primary btn-action btn-block">
                                <i class="fas fa-user-check"></i> Serve Next
                            </button>
                        </div>
                        <div class="col-md-6">
                            <button class="btn btn-success btn-action btn-block" onclick="playAudio()">
                                <i class="fas fa-bell"></i> Notify
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="details-card">
                <h5>Details for the Next Customer:</h5>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody id="customerDetails">
                            <!-- Fetched data will be displayed here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center mt-3" id="completeDeclineButtons" style="display: none;">
        <div class="col-md-8">
            <button id="completeBtn" class="btn btn-success btn-block mb-1">Complete</button>
        </div>
        <div class="col-md-8">
            <button id="NoshowBtn" class="btn btn-danger btn-block">No Show</button>
        </div>
    </div>
</div>

<!-- Add modal for email sent confirmation -->
<div class="modal fade" id="emailSentModal" tabindex="-1" role="dialog" aria-labelledby="emailSentModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="emailSentModalLabel">Email Sent</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center">
                Email has been sent successfully.
            </div>
        </div>
    </div>
</div>

<!-- New form for updating to 'served' -->
<form id="updateServedForm" method="post" action="update_status.php">
    <input type="hidden" name="trigger_update_served" value="1">
    <input type="submit" style="display: none;"> <!-- Hidden submit button -->
</form>

<!-- Modal for transaction completion -->
<div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="successModalLabel">Transaction Completed</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Your transaction has been completed.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal for action required -->
<div class="modal fade" id="incompleteServiceModal" tabindex="-1" role="dialog" aria-labelledby="incompleteServiceModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="incompleteServiceModalLabel">Action Required</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Please make sure the currently being served customer is marked as "served" or "no show" first.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- New form for updating to 'no show' -->
<form id="updateNoShowForm" method="post" action="update_status_no_show.php">
    <input type="hidden" name="trigger_update_no_show" value="1">
    <input type="submit" style="display: none;"> <!-- Hidden submit button -->
</form>

<!-- Modal for marking customer as no show -->
<div class="modal fade" id="noShowModal" tabindex="-1" role="dialog" aria-labelledby="noShowModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="noShowModalLabel">Customer Marked as No Show</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>The customer has been marked as "No Show."</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Audio element for notifications -->
<audio id="myAudio">
    <source src="bell-sound.mp3" type="audio/mp3">
    Your browser does not support the audio element.
</audio>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script>
// Variable to store the current customer's name
var currentCustomerName;
var cashierId = <?php echo json_encode($cashierId); ?>;
console.log("Cashier ID set to:", cashierId); // Debug: Log cashier ID

$(document).ready(function () {
    // Function to show the complete and decline buttons
    function showCompleteDeclineButtons() {
        $('#completeDeclineButtons').show();
    }

    // Function to hide the complete and decline buttons
    function hideCompleteDeclineButtons() {
        $('#completeDeclineButtons').hide();
    }

    // Complete button event handler
    $('#completeBtn').click(function () {
            console.log("Complete button clicked"); // Debug: Log button click
            console.log("Sending Cashier ID:", cashierId); // Debug: Log cashier ID
            $.post('update_status.php', { 
                trigger_update_served: 1, 
                cashier_id: cashierId 
            }, function (response) {
                console.log("Server response:", response); // Debug: Log server response
                if (response.status === 'success') {
                    $('#successModal').modal('show');
                    fetchCustomerDetails();
                } else {
                    alert('Error: ' + response.message);
                }
            }, 'json')
            .fail(function (xhr, status, error) {
                console.log("Error:", error); // Debug: Log any errors
                console.log("Response Text:", xhr.responseText); // Debug: Log response text
            });
        });

    // No Show button event handler
    $('#NoshowBtn').click(function () {
            console.log("No Show button clicked"); // Debug: Log button click
            console.log("Sending Cashier ID:", cashierId); // Debug: Log cashier ID
            $.post('update_status_no_show.php', { 
                trigger_update_no_show: 1, 
                cashier_id: cashierId 
            }, function (response) {
                console.log("Server response:", response); // Debug: Log server response
                if (response.status === 'success') {
                    $('#noShowModal').modal('show');
                    fetchCustomerDetails();
                } else {
                    alert('Error: ' + response.message);
                }
            }, 'json')
            .fail(function (xhr, status, error) {
                console.log("Error:", error); // Debug: Log any errors
                console.log("Response Text:", xhr.responseText); // Debug: Log response text
            });
        });


    // Serve Next button event handler
    $('#serveNextBtn').click(function () {
        // Check if there is a customer currently being served and not marked as served or no-show
        var currentQueueNumber = $('#currentQueueNumber').text().trim();

        if (currentQueueNumber !== 'N/A' && currentQueueNumber !== '') {
            // If there is a customer being served and not yet marked as served or no-show, show the modal popup
            $('#incompleteServiceModal').modal('show');
        } else {
            // Otherwise, proceed to serve the next pending customer
            // Send POST request to fetch_customer_details.php with the cashier ID
            $.ajax({
                url: 'fetch_customer_details.php',
                method: 'POST',
                data: {
                    cashier_id: <?php echo json_encode($_SESSION['cashier_id']); ?> // Send cashier ID to server
                },
                dataType: 'json',
                success: function (data) {
                    updateTable(data);

                    if (data.length > 0) {
                        showCompleteDeclineButtons();
                        currentCustomerName = data[0]['name']; // Assuming 'name' is the field containing the customer's name
                    } else {
                        hideCompleteDeclineButtons();
                    }
                },
                error: function (xhr, status, error) {
                    console.error('Error fetching data:', error);
                }
            });
        }
    });

    // Function to fetch and update customer details
    function fetchCustomerDetails() {
        $.ajax({
            url: 'fetch_customer_details.php',
            method: 'GET',
            dataType: 'json',
            success: function (data) {
                updateTable(data);

                if (data.length > 0) {
                    showCompleteDeclineButtons();
                    currentCustomerName = data[0]['name']; // Assuming 'name' is the field containing the customer's name
                } else {
                    hideCompleteDeclineButtons();
                }
            },
            error: function (xhr, status, error) {
                console.error('Error fetching data:', error);
            }
        });
    }

    // Function to update the table with data
    function updateTable(data) {
        var tableBody = $('#customerDetails');
        tableBody.empty();

        if (data.length > 0) {
            // Iterate through the fetched data and append rows to the table
            for (var key in data[0]) {
                if (key !== 'queue_number' && key !== 'id') {
                    var formattedKey = key.replace(/_/g, ' ');
                    var row = '<tr>' +
                        '<th>' + formattedKey.charAt(0).toUpperCase() + formattedKey.slice(1) + '</th>' +
                        '<td id="customer' + formattedKey.charAt(0).toUpperCase() + formattedKey.slice(1) + '">' + data[0][key] + '</td>' +
                        '</tr>';
                    tableBody.append(row);
                }
            }

            // Display queue_number and customer name in the "Current Queue" section
            $('#currentQueueNumber').text(data[0]['queue_number']);
            $('#currentCustomerName').text(data[0]['name']); // Assuming 'name' is the field containing the customer's name
        } else {
            tableBody.html('<tr><td colspan="2">No pending customer</td></tr>');
            $('#currentQueueNumber').text('N/A');
            $('#currentCustomerName').text('N/A');
        }
    }

// Function to announce the current customer queue number and cashier using text-to-speech
function announceQueueNumber(queueNumber, cashierName) {
    // Check if SpeechSynthesis is supported by the browser
    if ('speechSynthesis' in window) {
        var msg = new SpeechSynthesisUtterance();
        msg.text = 'Customer ' + queueNumber + ', please go to Cashier ' + cashierName;
        window.speechSynthesis.speak(msg);
    } else {
        // Fallback for browsers that do not support SpeechSynthesis
        alert('Text-to-speech is not supported in this browser.');
    }
}

// Function to play audio
function playAudio(cashierName) {
    // Check if the currentQueueNumber is not 'N/A'
    var currentQueueNumber = $('#currentQueueNumber').text().trim();
    if (currentQueueNumber && currentQueueNumber !== 'N/A') {
        announceQueueNumber(currentQueueNumber, cashierName);
    }
}

// Attach the playAudio function to the "Notify" button click event
$('.btn-action').click(function() {
    // Retrieve the cashier's name from the session or any other source
    var cashierName = '<?php echo isset($_SESSION["cashier_name"]) ? $_SESSION["cashier_name"] : "Unknown"; ?>';
    playAudio(cashierName);
});



    // Function to log out the user when the browser or tab is closed
    function autoLogout() {
        // Make an AJAX request to the server to log out the user
        $.ajax({
            url: 'logout.php',
            method: 'POST',
            success: function () {
                // You can perform other actions here if needed
            }
        });
    }

    // Attach the autoLogout function to the 'beforeunload' event
    window.onbeforeunload = function () {
        autoLogout();
    };
});
</script>

</body>
</html>
