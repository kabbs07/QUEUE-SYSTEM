<?php
// Include your database connection file
include_once 'db_connection.php'; // Update this line with your actual connection file

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $newName = isset($_POST['newName']) ? trim($_POST['newName']) : "";
    $newPassword = isset($_POST['newPassword']) ? trim($_POST['newPassword']) : "";
    
    // Set status to Active by default
    $newStatus = 'Active';
    
    // Validate the submitted data
    if (empty($newName) || empty($newPassword)) {
        echo "<script>alert('Name and Password are required fields.');";
        echo "window.location.href = 'cashier_list.php';</script>";
        exit();
    }

    // Map status strings to integers
    $statusMapping = [
        'Active' => 1,
        'Inactive' => 0
    ];

    // Check if the provided status is valid
    if (!array_key_exists($newStatus, $statusMapping)) {
        echo "<script>alert('Invalid status value.');";
        echo "window.location.href = 'cashier_list.php';</script>";
        exit();
    }

    // Convert status to its corresponding integer value
    $newStatus = $statusMapping[$newStatus];

    // Check if the name already exists
    $checkNameSql = "SELECT COUNT(*) as count FROM cashier WHERE name = ?";
    $checkNameStmt = $conn->prepare($checkNameSql);
    if ($checkNameStmt === false) {
        echo "<script>alert('Database error. Please try again later.');";
        echo "window.location.href = 'cashier_list.php';</script>";
        exit();
    }
    $checkNameStmt->bind_param("s", $newName);
    $checkNameStmt->execute();
    $checkNameResult = $checkNameStmt->get_result();
    $existingCount = $checkNameResult->fetch_assoc()['count'];

    if ($existingCount > 0) {
        // Redirect with an alert message
        echo "<script>alert('Name already exists. Please choose a different name.');";
        echo "window.location.href = 'cashier_list.php';</script>";
        exit();
    }

    // Set log_status to 0 during insertion
    $logStatus = 0;

    // Hash the password for security
    $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);

    // Insert data into the cashier table
    $insertSql = "INSERT INTO cashier (name, password, log_status, status) VALUES (?, ?, ?, ?)";
    $insertStmt = $conn->prepare($insertSql);
    if ($insertStmt === false) {
        echo "<script>alert('Database error. Please try again later.');";
        echo "window.location.href = 'cashier_list.php';</script>";
        exit();
    }
    $insertStmt->bind_param("ssis", $newName, $hashedPassword, $logStatus, $newStatus);
    $insertStmt->execute();

    // Check for errors
    if ($insertStmt->error) {
        echo "Error: " . $insertStmt->error;
    } else {
        // Redirect with a success message or to the actual page you want to redirect to
        echo "<script>alert('Cashier added successfully.');";
        echo "window.location.href = 'cashier_list.php';</script>";
        exit();
    }

    // Close the database connections
    $checkNameStmt->close();
    $insertStmt->close();
    $conn->close();
} else {
    // Redirect or handle the case where the form is not submitted
    header("Location: cashier_list.php"); // Replace with the actual page you want to redirect to
    exit();
}
?>
