<?php
include 'db_connection.php';

// Initialize variables
$totalServed = $totalPending = $peakHour = $missedQueues = '';
$averageServiceTimeRegularMinutes = $averageServiceTimeRegularSeconds = 0;
$averageServiceTimePriorityMinutes = $averageServiceTimePrioritySeconds = 0;

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['selectedDate'])) {
    // Get the selected date from the form
    $selectedDate = $_POST['selectedDate'];

    // Combine regular_queue and priority_queue tables focusing on status, queue_time, and queue_number
    $queuesUnionTable = "(SELECT id, status, queue_time, queue_number, start_service_time, end_service_time FROM regular_queue WHERE DATE(queue_time) = '$selectedDate')
                         UNION ALL
                         (SELECT id, status, queue_time, queue_number, start_service_time, end_service_time FROM priority_queue WHERE DATE(queue_time) = '$selectedDate')";
    
    // Calculate total customers served
    $sqlServed = "SELECT COUNT(*) as totalServed FROM ($queuesUnionTable) AS combined WHERE status = 'served'";
    $resultServed = $conn->query($sqlServed);
    $rowServed = $resultServed->fetch_assoc();
    $totalServed = $rowServed['totalServed'];

    // Calculate total customers in queue
    $sqlPending = "SELECT COUNT(*) as totalPending FROM ($queuesUnionTable) AS combined WHERE status = 'pending'";
    $resultPending = $conn->query($sqlPending);
    $rowPending = $resultPending->fetch_assoc();
    $totalPending = $rowPending['totalPending'];

    // Calculate peak hours
    $sqlPeakHours = "SELECT DATE_FORMAT(queue_time, '%h:%i %p') as startHour, DATE_FORMAT(queue_time + INTERVAL 1 HOUR, '%h:%i %p') as endHour, COUNT(*) as peakHourCount 
                     FROM ($queuesUnionTable) AS combined
                     GROUP BY startHour, endHour
                     ORDER BY peakHourCount DESC LIMIT 1";

    $resultPeakHours = $conn->query($sqlPeakHours);
    // Initialize $peakHour
    if ($resultPeakHours && $resultPeakHours->num_rows > 0) {
        $rowPeakHours = $resultPeakHours->fetch_assoc();
        $startHour = $rowPeakHours['startHour'];
        $endHour = $rowPeakHours['endHour'];
        $peakHour = $startHour . ' - ' . $endHour;
    }

    // Calculate missed queues
    $sqlMissedQueues = "SELECT COUNT(*) as missedQueues FROM ($queuesUnionTable) AS combined WHERE status = 'no show'";
    $resultMissedQueues = $conn->query($sqlMissedQueues);
    $rowMissedQueues = $resultMissedQueues->fetch_assoc();
    $missedQueues = $rowMissedQueues['missedQueues'];

    // Calculate average serving time for regular queue
    $averageServiceTimeRegularQuery = "SELECT AVG(TIMESTAMPDIFF(SECOND, start_service_time, end_service_time)) AS averageServiceTimeRegularSeconds
                                      FROM regular_queue
                                      WHERE status = 'served' AND DATE(queue_time) = '$selectedDate'";
    $resultAverageServiceTimeRegular = $conn->query($averageServiceTimeRegularQuery);
    if ($resultAverageServiceTimeRegular && $resultAverageServiceTimeRegular->num_rows > 0) {
        $rowAverageServiceTimeRegular = $resultAverageServiceTimeRegular->fetch_assoc();
        $averageServiceTimeRegularSeconds = round($rowAverageServiceTimeRegular['averageServiceTimeRegularSeconds']);
        // Calculate minutes and seconds from total seconds
        $averageServiceTimeRegularMinutes = intdiv($averageServiceTimeRegularSeconds, 60);
        $averageServiceTimeRegularSeconds %= 60;
    }

    // Calculate average serving time for priority queue
    $averageServiceTimePriorityQuery = "SELECT AVG(TIMESTAMPDIFF(SECOND, start_service_time, end_service_time)) AS averageServiceTimePrioritySeconds
                                       FROM priority_queue
                                       WHERE status = 'served' AND DATE(queue_time) = '$selectedDate'";
    $resultAverageServiceTimePriority = $conn->query($averageServiceTimePriorityQuery);
    if ($resultAverageServiceTimePriority && $resultAverageServiceTimePriority->num_rows > 0) {
        $rowAverageServiceTimePriority = $resultAverageServiceTimePriority->fetch_assoc();
        $averageServiceTimePrioritySeconds = round($rowAverageServiceTimePriority['averageServiceTimePrioritySeconds']);
        // Calculate minutes and seconds from total seconds
        $averageServiceTimePriorityMinutes = intdiv($averageServiceTimePrioritySeconds, 60);
        $averageServiceTimePrioritySeconds %= 60;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daily Reports</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="admin2.css">
  <link rel="icon" href="sdcafafa.jpg">

  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      background-color: #f8f9fa;
    }
    .container {
      margin-top: 20px;
    }
    h2 {
      color: black;
    }
    .metric-icon {
      font-size: 24px;
      margin-right: 10px;
    }
    .date-filter-form {
      max-width: 400px;
      margin: 0 auto;
      padding: 15px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .date-filter-form label {
      display: block;
      margin-bottom: 5px;
    }
    .date-filter-form input {
      width: 100%;
      padding: 8px;
      border: 1px solid #ced4da;
      border-radius: 4px;
      box-sizing: border-box;
    }
    .date-filter-form button {
      display: block;
      width: 100%;
      padding: 10px;
      background-color: #007bff;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .chart-container {
      margin-top: 20px;
      max-width: 600px;
      margin: 20px auto;
    }
  </style>
</head>
<body>

<?php include 'admin_navbar.php'?>

<div class="container">
  <h2 class="mb-4">Queue Overview Report</h2>

  <div class="filter-container">
    <form method="post" action="">
      <label for="selectedDate">Filter by Date:</label>
      <div class="input-group">
        <input type="date" class="form-control" id="selectedDate" name="selectedDate" required>
        <div class="input-group-append">
          <button class="btn btn-primary btn-filter" type="submit">Apply</button>
        </div>
      </div>
    </form>
  </div>

  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Metrics</th>
        <th>Values</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!empty($selectedDate)) : ?>
        <tr>
          <td><i class="fas fa-users metric-icon"></i>Total Customers Served</td>
          <td><?php echo $totalServed; ?></td>
        </tr>
        <tr>
          <td><i class="fas fa-user-friends metric-icon"></i>Total Customers in Queue</td>
          <td><?php echo $totalPending; ?></td>
        </tr>
        <tr>
          <td><i class="fas fa-chart-line metric-icon"></i>Peak Hours</td>
          <td><?php echo $peakHour; ?></td>
        </tr>
        <tr>
          <td><i class="fas fa-times-circle metric-icon"></i>Missed Queues</td>
          <td><?php echo $missedQueues; ?></td>
        </tr>
        <tr>
          <td><i class="fas fa-hourglass-half metric-icon"></i>Average Serving Time (Regular Queue)</td>
          <td><?php echo $averageServiceTimeRegularMinutes; ?> minutes and <?php echo $averageServiceTimeRegularSeconds; ?> seconds</td>
        </tr>
        <tr>
          <td><i class="fas fa-hourglass-half metric-icon"></i>Average Serving Time (Priority Queue)</td>
          <td><?php echo $averageServiceTimePriorityMinutes; ?> minutes and <?php echo $averageServiceTimePrioritySeconds; ?> seconds</td>
        </tr>
      <?php else : ?>
        <tr>
          <td colspan="2" class="text-center">Select a date to view metrics</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>

  <?php if (!empty($selectedDate)) : ?>
    <div class="chart-container">
      <canvas id="overviewChart"></canvas>
    </div>
  <?php endif; ?>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script> <!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script> <!-- DataTables Bootstrap 4 integration JS -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
  // Fetch data from PHP variables and use it in the JavaScript
  var totalServed = <?php echo $totalServed; ?>;
  var totalPending = <?php echo $totalPending; ?>;
  var missedQueues = <?php echo $missedQueues; ?>;

  // Dynamically update the chart data with PHP variables
  var chartData = {
    labels: ['Total Customers Served', 'Total Customers in Queue', 'Missed Queues'],
    datasets: [{
      label: 'Overview Metrics',
      data: [totalServed, totalPending, missedQueues],
      backgroundColor: 'rgba(75, 192, 192, 0.2)',
      borderColor: 'rgba(75, 192, 192, 1)',
      borderWidth: 1
    }]
  };

  var ctx = document.getElementById('overviewChart').getContext('2d');
  var overviewChart = new Chart(ctx, {
    type: 'bar',
    data: chartData,
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
</script>
</body>
</html>
