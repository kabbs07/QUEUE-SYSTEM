<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
include_once 'db_connection.php';

function getCurrentCustomer($conn, $queueTable, $cashierId) {
    $query = "SELECT id, email FROM $queueTable WHERE status = 'serving' AND cashierid = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $cashierId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return false;
}

function updateStatusAndTime($conn, $customerId, $queueTable) {
    $currentTime = date('Y-m-d H:i:s');
    $updateQuery = "UPDATE $queueTable SET status = 'no show', end_service_time = ? WHERE id = ? AND status = 'serving'";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param('si', $currentTime, $customerId);
    $stmt->execute();
    $success = $stmt->affected_rows > 0;
    $stmt->close();
    return $success;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $receivedParams = print_r($_POST, true); // Debug: Log received parameters
    error_log("Received POST parameters: " . $receivedParams);

    $missingParams = [];

    if (!isset($_POST['trigger_update_no_show'])) {
        $missingParams[] = 'trigger_update_no_show';
    }
    if (!isset($_POST['cashier_id'])) {
        $missingParams[] = 'cashier_id';
    }

    if (!empty($missingParams)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request: Missing parameters - ' . implode(', ', $missingParams)]);
        exit();
    }

    $cashierId = intval($_POST['cashier_id']);
    
    if ($cashierId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid cashier ID.']);
        exit();
    }

    $conn->begin_transaction();
    
    try {
        $currentCustomer = getCurrentCustomer($conn, 'priority_queue', $cashierId);
        $queueTable = 'priority_queue';

        if (!$currentCustomer) {
            $currentCustomer = getCurrentCustomer($conn, 'regular_queue', $cashierId);
            $queueTable = 'regular_queue';
        }

        if ($currentCustomer) {
            $customerId = $currentCustomer['id'];
            $customerEmail = $currentCustomer['email'];

            $statusUpdateSuccess = updateStatusAndTime($conn, $customerId, $queueTable);

            if ($statusUpdateSuccess) {
                $conn->commit();

                if (!empty($customerEmail)) {
                    try {
                        $mail = new PHPMailer(true);
                        $mail->isSMTP();
                        $mail->Host = 'smtp.gmail.com';
                        $mail->SMTPAuth = true;
                        $mail->Username = 'alfonsomarcus778@gmail.com';
                        $mail->Password = 'mvseklznmebkhagr';
                        $mail->SMTPSecure = 'tls';
                        $mail->Port = 587;

                        $mail->setFrom('alfonsomarcus778@gmail.com', 'Queue Ease');
                        $mail->addAddress($customerEmail);
                        $mail->isHTML(true);
                        $mail->Subject = 'Your Transaction is Complete';
                        $mail->Body = '
                            <html>
                            <head>
                                <style>
                                    body { font-family: Arial, sans-serif; }
                                    .container { max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f8f8f8; border: 1px solid #ddd; border-radius: 5px; }
                                    h1 { color: #333; }
                                    p { color: #555; }
                                </style>
                            </head>
                            <body>
                                <div class="container">
                                    <a href="https://imgbb.com/"><img src="https://i.ibb.co/BjK9sg2/logo-header.png" alt="logo-header" border="0"></a>
                                    <h1>Notification: Your Appointment</h1>
                                    <p>Dear Customer,</p>
                                    <p>We regret to inform you that you have been marked as a no show for your appointment. Please contact us for further assistance.</p>
                                    <p>Thank you.</p>
                                </div>
                            </body>
                            </html>';
                        $mail->send();
                    } catch (Exception $e) {
                        echo json_encode(['status' => 'error', 'message' => 'Failed to send email: ' . $e->getMessage()]);
                        return;
                    }
                }

                echo json_encode(['status' => 'success', 'customer_id' => $customerId]);
            } else {
                $conn->rollback();
                echo json_encode(['status' => 'error', 'message' => 'Failed to update record']);
            }
        } else {
            $conn->rollback();
            echo json_encode(['status' => 'error', 'message' => 'No customer currently being served.']);
        }
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['status' => 'error', 'message' => 'Transaction error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>
