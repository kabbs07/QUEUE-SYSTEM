<?php
session_start();

// Include your database connection code here
include 'db_connection.php';

if (isset($_POST['id'])) {
    $optionId = $_POST['id'];

    // Sanitize the input (you can use prepared statements for better security)
    $optionId = mysqli_real_escape_string($conn, $optionId);

    // Delete the option from the database
    $sql = "DELETE FROM transaction_options WHERE id = '$optionId'";

    if ($conn->query($sql) === TRUE) {
        echo 'success'; // Send a success response back to the AJAX request
        exit();
    } else {
        echo 'error';
    }

    // Close the database connection
    $conn->close();
}
?>
