<?php
include 'db_connection.php';

// Get current date
$currentDate = date("Y-m-d");

// Check if a record exists for the current date
$checkRecordSql = "SELECT * FROM daily_queue_numbers WHERE date = '$currentDate'";
$checkRecordResult = $conn->query($checkRecordSql);

if ($checkRecordResult->num_rows > 0) {
    // Record exists, get the current queue number and increment it
    $row = $checkRecordResult->fetch_assoc();
    $currentQueueNumber = $row['queue_number'];
    $newQueueNumber = str_pad(intval($currentQueueNumber) + 1, 3, '0', STR_PAD_LEFT);

    // Update the queue number in the database
    $updateQueueNumberSql = "UPDATE daily_queue_numbers SET queue_number = '$newQueueNumber' WHERE date = '$currentDate'";
    $conn->query($updateQueueNumberSql);
} else {
    // No record for the current date, insert a new record with queue number 001
    $newQueueNumber = "001";
    $insertQueueNumberSql = "INSERT INTO daily_queue_numbers (date, queue_number) VALUES ('$currentDate', '$newQueueNumber')";
    $conn->query($insertQueueNumberSql);
}

// Return the generated queue number
echo json_encode(['queueNumber' => $newQueueNumber]);
?>
