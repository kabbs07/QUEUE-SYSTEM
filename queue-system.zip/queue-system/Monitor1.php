<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Queue-ease</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link rel="icon" href="sdcafafa.jpg">
  <style>
    /* Styles */
    /* Add border to columns */
    .custom-border {
      height: 100vh;
      background-color: #212529; /* Dark background */
      padding: 20px;
    }
    /* Add border to sub-columns */
    .sub-column {
      width: 100%;
      border: 1px solid #6c757d; /* Grey border */
      padding: 20px;
      margin-bottom: 20px;
      background-color: rgba(52, 58, 64, 0.7); /* Dark background with 80% opacity */
      border-radius: 8px; /* Rounded corners */
      height: calc(100% / 1); /* Divide the height evenly among three sub-columns */
      text-align: center;
    }
    .sub-column2 {
        width: 100%;
        border: 1px solid #6c757d; /* Grey border */
        padding: 20px;
        margin-bottom: 20px;
        background-color: rgba(52, 58, 64, 0.7); /* Dark background with 80% opacity */
        border-radius: 8px; /* Rounded corners */
        height: calc(100% / 1); /* Divide the height evenly among three sub-columns */
        text-align: center;
    }
    .sub-column h3 {
      color: #FFC917; /* Yellow heading */
    }
    .sub-column2 h3 {
      color: #dc3545; /* Red heading */
      font-size: 55px;
    }
    .sub-column p, .sub-column2 p {
      color: #ffffff; /* White text */
    }
    h4 {
        color: #fff;
        font-size: 30px;
    }
    #counter1NowServing, #counter2NowServing {
      color: #fff;
      font-size: 30px;
    }
    .serving-customers {
      color: #fff;
      font-size: 40px;
      list-style: none;
    }
    li{
        list-style:none;
    }
    /* Animation background */
    @keyframes gradientAnimation {
        0% {
            background-position: 0% 50%;
        }
        50% {
            background-position: 100% 50%;
        }
        100% {
            background-position: 0% 50%;
        }
    }
    .animation-background {
        background: linear-gradient(-45deg, #3D0000, #7A0000, #CD0B0B, #FF0022);
        background-size: 400% 400%;
        animation: gradientAnimation 10s ease infinite;
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row">
    <!-- First column -->
    <div class="col custom-border d-flex flex-column align-items-center justify-content-center animation-background">
      <!-- Sub-columns -->
      <div class="sub-column">
        <h3>PENDING QUEUES</h3>
        <br><br>
        <h4 id="queueNumber1">--</h4>
        <br><br>
        <h4 id="queueNumber2">--</h4>
        <br><br>
        <h4 id="queueNumber3">--</h4>
        <br><br>
        <h4 id="queueNumber4">--</h4>
        <br><br>
        <h4 id="queueNumber5">--</h4>
        <br><br>
        <h4 id="queueNumber6">--</h4>
        <br><br>
        <h4 id="queueNumber7">--</h4>
      </div>
    </div>
    <!-- Second column -->
    <div class="col custom-border d-flex flex-column align-items-center justify-content-center">
        <!-- Sub-columns -->
        <div class="sub-column2">
            <h3>Now Serving</h3>
            <div class="serving-customers" id="servingCustomers">
              <!-- Serving customers will be dynamically inserted here -->
            </div>
        </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
$(document).ready(function() {
    // Function to fetch and update data from the server
    function updateData() {
        // Fetch currently serving customers
        $.ajax({
            url: 'fetch_current_serving.php',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                // Clear existing serving customers
                $('#servingCustomers').empty();

                // Check if there are serving customers
                if (data.length > 0) {
                    // Create a list to display serving customers
                    var servingList = $('<ul>');
                    // Loop through the serving customers and add them to the list
                    data.forEach(function(customer) {
                        // Fetch cashier name based on cashier ID
                        fetchCashierName(customer.cashierid, function(cashierName) {
                            // Create list item with cashier name and queue number
                            var listItem = $('<li>').text(cashierName + ' ' + customer.queue_number);
                            servingList.append(listItem);
                        });
                    });
                    // Append the serving list to the container
                    $('#servingCustomers').append(servingList);
                } else {
                    // If no serving customers, display a message
                    $('#servingCustomers').text('No customers currently being served.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching serving customers:', error);
                // Display an error message
                $('#servingCustomers').text('Error fetching serving customers.');
            }
        });

        // Fetch pending queue numbers
        $.ajax({
            url: 'fetch_pending_queue.php',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                // Update pending queue numbers
                if (data.length > 0) {
                    data.forEach(function(item, index) {
                        if (index < 6) {
                            $('#queueNumber' + (index + 1)).text(item.queue_number);
                        }
                    });
                    // Clear unused placeholders
                    for (let i = data.length; i < 6; i++) {
                        $('#queueNumber' + (i + 1)).text('--');
                    }
                } else {
                    // Reset all placeholders
                    $('[id^="queueNumber"]').text('--');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching pending queue data:', error);
                // Reset all placeholders in case of error
                $('[id^="queueNumber"]').text('--');
            }
        });
    }

    // Function to fetch cashier name based on cashier ID
    function fetchCashierName(cashierId, callback) {
        $.ajax({
            url: 'fetch_cashier_name.php',
            method: 'GET',
            data: { cashier_id: cashierId },
            dataType: 'json',
            success: function(data) {
                if (data.name) {
                    callback(data.name);
                } else {
                    callback('Unknown cashier');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching cashier name:', error);
                callback('Unknown cashier');
            }
        });
    }

    // Call updateData every 3 seconds
    setInterval(updateData, 3000);
});
</script>

</body>
</html>
