<?php
session_start();
include_once 'db_connection.php';

// Function to update the start_service_time for a customer
function updateStartServiceTime($cashierId) {
    global $conn;

    // Initialize response array
    $response = array('status' => 'failure', 'message' => 'No pending customers.');

    // Determine the order of queues to check
    $queueTables = ['priority_queue', 'regular_queue'];

    // Iterate through both queue tables (priority then regular) to find the next pending customer
    foreach ($queueTables as $queueTable) {
        // Query to find the next pending customer in the current queue table
        $sql = "SELECT id FROM $queueTable WHERE status = 'pending' ORDER BY queue_number ASC LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if a pending customer is found
        if ($result->num_rows > 0) {
            // Fetch the next customer
            $nextCustomer = $result->fetch_assoc();
            $customerId = $nextCustomer['id'];

            // Get the current timestamp
            $currentTime = date('Y-m-d H:i:s');

            // Update the start_service_time for the next customer in the specified queue table
            $updateQuery = "UPDATE $queueTable SET start_service_time = ? WHERE id = ?";
            $updateStmt = $conn->prepare($updateQuery);
            $updateStmt->bind_param('si', $currentTime, $customerId);
            $updateStmt->execute();

            // Check if the update was successful
            if ($updateStmt->affected_rows > 0) {
                // Successful update
                $response['status'] = 'success';
                $response['message'] = 'Start service time updated successfully.';
            } else {
                // Update failed
                $response['message'] = 'Failed to update start service time.';
            }

            // Close the statement
            $updateStmt->close();

            // Break out of the loop since we found a pending customer
            break;
        }

        // Close the statement after checking the queue table
        $stmt->close();
    }

    // Return the response as a JSON object
    echo json_encode($response);
}

// Check if the request method is POST and the required data is provided
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cashier_id'])) {
    $cashierId = intval($_POST['cashier_id']);
    updateStartServiceTime($cashierId);
} else {
    echo json_encode(array('status' => 'failure', 'message' => 'Invalid request.'));
}
?>
