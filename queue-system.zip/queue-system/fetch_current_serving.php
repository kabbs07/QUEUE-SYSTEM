<?php
include_once 'db_connection.php';

// Set header to indicate the response type as JSON
header('Content-Type: application/json');

try {
    // Fetch all currently serving customers from both priority_queue and regular_queue
    $sql = "SELECT queue_number, cashierid FROM (
                (SELECT queue_number, cashierid FROM priority_queue WHERE status = 'serving')
                UNION
                (SELECT queue_number, cashierid FROM regular_queue WHERE status = 'serving')
            ) AS combined_serving";
    $result = $conn->query($sql);

    $data = []; // Initialize an empty array

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row; // Add each row to the array, including cashier_id
        }
    }

    // Encode and return the data as JSON
    echo json_encode($data);
} catch (Exception $e) {
    // In case of an error, return a JSON object with an error message
    echo json_encode(['error' => 'An error occurred while fetching data: ' . $e->getMessage()]);
} finally {
    // Close the database connection
    $conn->close();
}
