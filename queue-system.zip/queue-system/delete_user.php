<?php
session_start();

// Include your database connection file
include_once 'db_connection.php';

// Check if user_id is set and not empty
if (isset($_GET['user_id']) && !empty($_GET['user_id'])) {
    $userId = $_GET['user_id'];

    // Perform the deletion
    $sql = "DELETE FROM userss WHERE id = $userId";
    if ($conn->query($sql) === TRUE) {
        // Redirect to the user management page or wherever you want after deletion
        header("Location: users.php");
        exit();
    } else {
        // Handle the error, if any
        echo "Error deleting record: " . $conn->error;
    }
} else {
    // Redirect to the user management page if user_id is not set
    header("Location: users.php");
    exit();
}

// Close the database connection
$conn->close();
?>
