<?php
session_start();
include_once 'db_connection.php';

// Validate POST data
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['cashierId']) && isset($_POST['password'])) {
    $cashierId = $_POST['cashierId'];
    $password = $_POST['password'];

    // Fetch cashier details based on the selected ID and active status
    $sql = "SELECT id, name, password FROM cashier WHERE id = ? AND status = 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $cashierId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $storedPassword = $row['password'];

        // Verify the password
        if (password_verify($password, $storedPassword)) {
            // Update log_status to 'in use' (1)
            $sqlUpdate = "UPDATE cashier SET log_status = 1 WHERE id = ?";
            $stmtUpdate = $conn->prepare($sqlUpdate);
            $stmtUpdate->bind_param("i", $cashierId);
            $stmtUpdate->execute();

            // Start the session with cashier ID and name
            $_SESSION['cashier_id'] = $cashierId;
            $_SESSION['cashier_name'] = $row['name'];

            // Redirect to cashier dashboard
            header("Location: cashier_dashboard.php");
            exit();
        } else {
            // Password verification failed
            $_SESSION['login_error'] = "Incorrect password. Please try again.";
            header("Location: cashier_login.php");
            exit();
        }
    } else {
        // Cashier not found or inactive
        $_SESSION['login_error'] = "The selected cashier is not active.";
        header("Location: cashier_login.php");
        exit();
    }

    $stmt->close();
} else {
    // Invalid request
    header("Location: cashier_login.php");
    exit();
}
?>
