<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Q-Ease</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&amp;display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <link rel="stylesheet" href="get_queue.css">
    <link rel="icon" href="sdcafafa.jpg">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <style>
        /* Custom styles */
        .school-logo {
            max-width: 30%;
            max-height: 20%;
            display: inline-block;
            vertical-align: middle;
        }

        .btn {
            width: 450px;
            max-width: 100%;
            border-color: crimson;
            border-width: 4px;
        }

        .btn:hover {
            border-color: goldenrod;
        }

        .dropdown-menu {
            width: 450px;
            max-width: 100%;
            border-color: goldenrod;
            border-width: 2px;
        }

        .process {
            border-color: transparent;
        }

        .process:hover {
            border-color: #2ECC71;
        }

        /* Add this style to center the "Get Queue" button */
        .modal-footer {
            text-align: center;
        }

        #getQueueButton {
            margin: 0 auto;
        }

        #closeButton {
            margin: 0 auto;
        }

        #printButton {
            margin: 0 auto;
            border-color: #198754;
        }

        .form-control {
            border-color: crimson;
            border-width: 4px;
        }

        .form-control:hover {
            border-color: goldenrod;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg shadow border-bottom border-2 border-danger">
        <div class="container-fluid">
            <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-content">
                <div class="hamburger-toggle">
                    <div class="hamburger">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </button>
            <div class="collapse navbar-collapse" id="navbar-content">
                <ul class="navbar-nav mr-auto mb-2 mb-lg-0">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" data-bs-auto-close="outside">Related Platforms</a>
                        <ul class="dropdown-menu shadow">
                            <li><a class="dropdown-item" href="https://stdominiccollege.edu.ph/" target="blank">SDCA Website</a></li>
                            <li><a class="dropdown-item" href="https://stdominiccollege.edu.ph/SDCALMSv2/index.php/Main" target="blank">iClass</a></li>
                            <li><a class="dropdown-item" href="https://stdominiccollege.edu.ph/sdcap/index.php/Student/Main" target="blank">SDCA Old Portal</a></li>
                            <li><a class="dropdown-item" href="https://stdominiccollege.edu.ph/index.php/research" target="blank">RDO Microsite</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"><Q-Ease></Q-Ease></a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#" tabindex="-1" data-bs-toggle-theme="true" aria-disabled="true">Toggle Theme <i class="fa fa-adjust"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <section class="my-5">
        <div class="container">
            <div class="p-4 border border-2 border-danger rounded-4">
                <center>
                    <img src="sdcalogo.png" alt="SDCA" class="school-logo">
                    <h1>Get <span class="text-danger">Queue</span></h1>
                    <br>
                    <p class="lead">Type of Customer:</p>
                    <p>Note: Priority Customers must present a valid ID that they are either PWD or Senior.</p>

                    <!-- Customer Type Dropdown -->
                    <div class="dropdown-center">
                        <button type="button" class="btn btn-lg dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" changeable="true" id="customerDropdown">
                            Choose:
                        </button>
                        <ul class="dropdown-menu">
                            <?php
                            include 'db_connection.php';
                            // Fetch options from the database for Type of Customer
                            $customerOptionsSql = "SELECT option_name FROM transaction_options WHERE option_type = 'customer'";
                            $customerOptionsResult = $conn->query($customerOptionsSql);
                            if ($customerOptionsResult->num_rows > 0) {
                                while ($row = $customerOptionsResult->fetch_assoc()) {
                                    echo "<li><a class='dropdown-item'>" . $row['option_name'] . "</a></li>";
                                }
                            }
                            ?>
                        </ul>
                    </div>

                    <!-- Service Type Dropdown -->
                    <br><br>
                    <b><p class="lead">Type of Service:</p></b>
                    <div class="dropdown-center">
                        <button type="button" class="btn btn-lg dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" changeable="true" id="serviceDropdown">
                            Choose:
                        </button>
                        <ul class="dropdown-menu">
                            <?php
                            // Fetch options from the database for Type of Service
                            $serviceOptionsSql = "SELECT option_name FROM transaction_options WHERE option_type = 'service'";
                            $serviceOptionsResult = $conn->query($serviceOptionsSql);
                            if ($serviceOptionsResult->num_rows > 0) {
                                while ($row = $serviceOptionsResult->fetch_assoc()) {
                                    echo "<li><a class='dropdown-item'>" . $row['option_name'] . "</a></li>";
                                }
                            }
                            ?>
                        </ul>
                    </div>

                    <!-- Payment For Dropdown -->
                    <br><br>
                    <b><p class="lead">Payment For:</p></b>
                    <div class="dropdown-center">
                        <button type="button" class="btn btn-lg dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" changeable="true" id="paymentForDropdown">
                            Choose:
                        </button>
                        <ul class="dropdown-menu">
                            <?php
                            // Fetch options from the database for Payment For
                            $paymentForOptionsSql = "SELECT option_name FROM transaction_options WHERE option_type = 'payment_for'";
                            $paymentForOptionsResult = $conn->query($paymentForOptionsSql);
                            if ($paymentForOptionsResult->num_rows > 0) {
                                while ($row = $paymentForOptionsResult->fetch_assoc()) {
                                    echo "<li><a class='dropdown-item'>" . $row['option_name'] . "</a></li>";
                                }
                            }
                            ?>
                        </ul>
                    </div>

                    <!-- Payment Mode Dropdown -->
                    <br><br>
                    <b><p class="lead">Mode of Payment:</p></b>
                    <div class="dropdown-center">
                        <button type="button" class="btn btn-lg dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" changeable="true" id="paymentModeDropdown">
                            Choose:
                        </button>
                        <ul class="dropdown-menu">
                            <?php
                            // Fetch options from the database for Mode of Payment
                            $paymentModeOptionsSql = "SELECT option_name FROM transaction_options WHERE option_type = 'payment_mode'";
                            $paymentModeOptionsResult = $conn->query($paymentModeOptionsSql);
                            if ($paymentModeOptionsResult->num_rows > 0) {
                                while ($row = $paymentModeOptionsResult->fetch_assoc()) {
                                    echo "<li><a class='dropdown-item'>" . $row['option_name'] . "</a></li>";
                                }
                            }
                            ?>
                        </ul>
                    </div>

                    <!-- Name and Student Number Input -->
                    <br><br>
                    <b><p class="lead">Name:</p></b>
                    <div class="input-group input-group-lg mb-3" style="width: 450px; max-width: 100%;">
                        <input type="text" class="form-control" placeholder="Enter your name" aria-label="Name" aria-describedby="name-addon">
                    </div>
                    <b><p class="lead">Student Number:</p></b>
                    <div class="input-group input-group-lg mb-3" style="width: 450px; max-width: 100%;">
                        <input type="text" class="form-control" placeholder="e.g: 201901730" aria-label="Student Number" aria-describedby="studentnumber-addon" id="studentNumberInput">
                    </div>

                    <!-- Email Input -->
                    <b><p class="lead">Email:</p></b>
                    <div class="input-group input-group-lg mb-3" style="width: 450px; max-width: 100%;">
                        <input type="email" class="form-control" placeholder="Enter your email" aria-label="Email" aria-describedby="email-addon">
                    </div>
                    <p style="font-size: 15px;">Optional: For those who want to be notified Via Email.</p>

                    <!-- Process Queue Button -->
                    <br><br>
                    <div class="print">
                        <button class="btn process btn-success btn-lg" type="button" aria-expanded="false" id="processQueueButton">Process Queue</button>
                    </div>
                </center>
            </div>
        </div>
    </section>

    <!-- Modals -->
    <!-- Confirmation Modal -->
    <div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmationModalLabel">Confirmation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Selected Options:</p>
                    <ul id="selectedOptionsList"></ul>
                </div>
                <div class="modal-footer">
                    <!-- Change the button to "Get Queue" and apply the same styles as "Process Queue" button -->
                    <button class="btn process btn-success btn-lg center-block" id="getQueueButton" type="button" aria-expanded="false" data-bs-dismiss="modal">Get Queue</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Queue Details Modal -->
    <div class="modal fade" id="queueDetailsModal" tabindex="-1" aria-labelledby="queueDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="queueDetailsModalLabel">Queue Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <p class="text-center display-3 fw-bold" id="queueNumberDisplay"></p>
                    <p id="estimatedWaitTime"></p>
                    <p class="text-warning-emphasis" style="font-size: 15px;">Please screenshot your queue number for reference.</p>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-danger btn-lg" id="closeButton" type="button" aria-expanded="false" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function () {
            // Handle dropdown item click
            $(".dropdown-menu").on("click", "a.dropdown-item", function () {
                // Update the button text to the clicked item
                var selectedText = $(this).text();
                $(this).closest(".dropdown-menu").prev(".dropdown-toggle").text(selectedText);
            });

            // Process Queue button event handler
            $("#processQueueButton").on("click", function () {
                // Get selected options from the form
                var name = $("input[type='text']").val();
                var studentNumber = $("#studentNumberInput").val(); // Get the student number
                var selectedCustomer = $("#customerDropdown").text().trim();
                var selectedService = $("#serviceDropdown").text().trim();
                var selectedPaymentFor = $("#paymentForDropdown").text().trim();
                var selectedPaymentMode = $("#paymentModeDropdown").text().trim();
                var email = $("input[type='email']").val();

                // Validate that options are selected and student number is provided
                if (selectedCustomer === "Choose:" || selectedService === "Choose:" || selectedPaymentFor === "Choose:" || selectedPaymentMode === "Choose:") {
                    alert("Please ensure all required options are selected and your student number is provided before processing the queue.");
                    return;
                }

                // Determine the appropriate URL based on the selected customer type
                var url = "";
                if (selectedCustomer.toLowerCase().includes("priority")) {
                    url = "priority_queue.php"; // URL for inserting data into priority queue table
                } else {
                    url = "regular_queue.php"; // URL for inserting data into regular queue table
                }

                // Send an AJAX request to insert the selected options into the appropriate queue table
                $.ajax({
                    type: "POST",
                    url: "insert_queue.php",
                    data: {
                        name: name,
                        studentNumber: studentNumber,
                        selectedCustomer: selectedCustomer,
                        selectedService: selectedService,
                        selectedPaymentFor: selectedPaymentFor,
                        selectedPaymentMode: selectedPaymentMode,
                        email: email
                    },
                    dataType: "json",
                    success: function(response) {
                        if (response.success) {
                            // Call showQueueDetails with queue number and average service time
                            showQueueDetails(response.queueNumber, response.average_service_time);
                        } else {
                            alert("Failed to insert data into the database: " + response.error);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                        alert("Error occurred during AJAX request: " + error);
                    }
                });
            });
        });

        // Function to display queue details and average service time
        function showQueueDetails(queueNumber, averageServiceTime) {
            // Display the queue number in the modal
            $("#queueNumberDisplay").text(queueNumber);
            
            // Format average service time
            var minutes = Math.floor(averageServiceTime);
            var seconds = Math.round((averageServiceTime - minutes) * 60);
            
            var formattedTime;
            if (minutes > 0) {
                // Format average service time as minutes and seconds
                formattedTime = minutes + " minute" + (minutes > 1 ? "s" : "") + " and " + seconds + " second" + (seconds > 1 ? "s" : "");
            } else {
                // Format average service time as seconds only
                formattedTime = seconds + " second" + (seconds > 1 ? "s" : "");
            }
            
            // Display the formatted average service time in the modal
            $("#estimatedWaitTime").text("Average Service Time: " + formattedTime);
            
            // Reset input fields and dropdowns
            $("input[type='text']").val('');
            $("input[type='email']").val('');
            $(".dropdown-toggle").text('Choose:');
            
            // Show the modal for displaying queue details
            $("#queueDetailsModal").modal("show");
        }
    </script>
    <script src="./script.js"></script>
</body>
</html>
