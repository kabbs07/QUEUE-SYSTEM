<?php
session_start();
include_once 'db_connection.php';

// Check if a cashier session is already active
if (isset($_SESSION['cashier_id'])) {
    header("Location: cashier_dashboard.php");
    exit();
}
// Process the login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the selected cashier ID and password from the form
    $selectedCashierId = isset($_POST['cashier_id']) ? $_POST['cashier_id'] : null;
    $password = isset($_POST['password']) ? $_POST['password'] : null;

    // Validate the selected cashier ID and password
    if ($selectedCashierId !== null && $password !== null) {
        // Fetch cashier details based on the selected ID and active status
        $sql = "SELECT id, name, log_status, password FROM cashier WHERE id = ? AND status = 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $selectedCashierId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            // Verify password
            if (password_verify($password, $row['password'])) {
                // Check if the cashier is available for use (log_status = 0)
                if ($row['log_status'] == 0) {
                    // Update log_status to 'in use' (1)
                    $sqlUpdate = "UPDATE cashier SET log_status = 1 WHERE id = ?";
                    $stmtUpdate = $conn->prepare($sqlUpdate);
                    $stmtUpdate->bind_param("i", $row['id']);
                    $stmtUpdate->execute();

                    // Start the session with cashier ID and name
                    $_SESSION['cashier_id'] = $row['id'];
                    $_SESSION['cashier_name'] = $row['name'];

                    // Redirect to cashier dashboard
                    header("Location: cashier_dashboard.php");
                    exit();
                } else {
                    // Handle error if cashier is already in use
                    $error_message = "The selected cashier is already in use.";
                }
            } else {
                // Handle error if password does not match
                $error_message = "Incorrect password.";
            }
        } else {
            // Handle error if cashier not found or inactive
            $error_message = "The selected cashier is not active.";
        }

        $stmt->close();
    } else {
        // Handle error if cashier ID or password is not selected
        $error_message = "Please select a valid cashier and enter the password.";
    }
}

// Fetch active cashier data for the form
$sql = "SELECT id, name FROM cashier WHERE status = 1";
$result = $conn->query($sql);

// Initialize an array to store cashier options
$cashierOptions = array();

// Fetch rows and populate cashier options
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cashierOptions[] = '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="icon" href="sdcafafa.jpg">
    <link rel="stylesheet" href="index.css">
    <title>Cashier Login</title>
    <style>
        body {
            background-color: #f2f2f2;
        }

        .container {
            margin-top: 50px;
        }

        .login-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .login-container h2 {
            color: #CD0B0B;
            font-size: 25px;
        }

        .login-container form {
            margin-top: 20px;
        }

        .login-container label {
            font-weight: bold;
        }

        .login-container .form-control {
            margin-bottom: 15px;
        }

        .login-container .btn-primary {
            background-color: #CD0B0B;
            border: none;
        }

        .login-container a {
            display: block;
            margin-top: 15px;
            text-align: center;
            color: #CD0B0B;
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg topNav">
        <div class="container-fluid topNav">
            <a class="navbar-brand" href="index.php">Queue Ease</a>
        </div>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4 login-container">
                <h2 class="text-center mb-4">Please Select a Cashier</h2>

                <!-- Display error message if any -->
                <?php if (isset($error_message)) : ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>

                <!-- Login form -->
                <form action="cashier_login.php" method="post">
    <div class="form-group">
        <label for="cashier_id"><i class="fas fa-cash-register"></i> Cashier:</label>
        <select class="form-control" id="cashier_id" name="cashier_id" required>
            <?php
            // Output cashier options
            foreach ($cashierOptions as $option) {
                echo $option;
            }
            ?>
        </select>
    </div>
    <div class="form-group">
        <label for="password"><i class="fas fa-key"></i> Password:</label>
        <input type="password" class="form-control" id="password" name="password" required>
    </div>
    <button type="submit" class="btn btn-primary btn-block" style="width:100%;">Login</button>
</form>

                <a href="login.php"><i class="fas fa-user-shield"></i> Admin</a>
            </div>
        </div>
    </div>

</body>

</html>
