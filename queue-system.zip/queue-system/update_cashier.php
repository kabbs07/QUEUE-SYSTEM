<?php
// Include your database connection file
include_once 'db_connection.php'; // Update this line with your actual connection file

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $editCashierId = isset($_POST['editCashierId']) ? $_POST['editCashierId'] : "";
    $editName = isset($_POST['editName']) ? $_POST['editName'] : "";
    $editStatus = isset($_POST['editStatus']) ? $_POST['editStatus'] : "";
    $editPassword = isset($_POST['editPassword']) ? $_POST['editPassword'] : "";

    // Validate the submitted data
    if (empty($editCashierId) || empty($editName)) {
        echo "<script>alert('ID and Name are required fields.');";
        echo "window.location.href = 'cashier_list.php';</script>";
        exit();
    }

    // Map status strings to integers
    $statusMapping = [
        '1' => 'Active',
        '0' => 'Inactive'
    ];

    // Check if the provided status is valid
    if (!array_key_exists($editStatus, $statusMapping)) {
        echo "<script>alert('Invalid status value.');";
        echo "window.location.href = 'cashier_list.php';</script>";
        exit();
    }

    // Prepare the update query
    if (!empty($editPassword)) {
        // If password is provided, hash it
        $hashedPassword = password_hash($editPassword, PASSWORD_BCRYPT);
        $updateSql = "UPDATE cashier SET name = ?, status = ?, password = ? WHERE id = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("sisi", $editName, $editStatus, $hashedPassword, $editCashierId);
    } else {
        // If password is not provided, do not update it
        $updateSql = "UPDATE cashier SET name = ?, status = ? WHERE id = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("sii", $editName, $editStatus, $editCashierId);
    }

    // Execute the update query
    $updateStmt->execute();

    // Check for errors
    if ($updateStmt->error) {
        echo "Error: " . $updateStmt->error;
    } else {
        // Redirect with a success message or to the actual page you want to redirect to
        echo "<script>alert('Cashier updated successfully.');";
        echo "window.location.href = 'cashier_list.php';</script>";
        exit();
    }

    // Close the database connections
    $updateStmt->close();
    $conn->close();
} else {
    // Redirect or handle the case where the form is not submitted
    header("Location: cashier_list.php"); // Replace with the actual page you want to redirect to
    exit();
}
?>
