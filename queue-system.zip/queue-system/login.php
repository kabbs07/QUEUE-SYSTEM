<?php
session_start();

// Include your database connection file
include_once 'db_connection.php';

// Initialize variables for messages and errors
$error_message = "";
$success_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $username = isset($_POST['username']) ? $_POST['username'] : "";
    $password = isset($_POST['password']) ? $_POST['password'] : "";

    // Validate the submitted data (you can add more validation as needed)

    // Fetch user data from the database based on the provided username
    $sql = "SELECT id, username, password FROM userss WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Verify the password
        $row = $result->fetch_assoc();
        $hashed_password = $row['password'];
    
        if (password_verify($password, $hashed_password)) {
            // Password is correct, start the session
            $_SESSION['user_id'] = $row['id'];
            
            // Update the session variable with the new username
            $_SESSION['username'] = $row['username'];
    
            // Redirect to a secure page or dashboard
            header("Location: admin_dashboard.php");
            exit();
        } else {
            $error_message = "Invalid username or password.";
        }
    } else {
        $error_message = "Invalid username or password.";
    }
    
    // Close the database connection
    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
     <link rel="stylesheet" href="index.css">
     <link rel="icon" href="sdcafafa.jpg">


    <title>Login Page</title>
    <style>
        body {
        background-color: #f2f2f2; /* Adjust background color of the main content */
        }

        .container {
            margin-top: 50px;
        }

        .login-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .login-container h2 {
            color: #CD0B0B;
        }

        .login-container form {
            margin-top: 20px;
        }

        .login-container label {
            font-weight: bold;
        }

        .login-container .form-control {
            margin-bottom: 15px;
        }

        .login-container .btn-primary {
            background-color: #CD0B0B;
            border: none;
        }

        .login-container a {
            display: block;
            margin-top: 15px;
            text-align: center;
            color: #CD0B0B;
        }
    </style>
    <script>
        function validateForm() {
            var username = document.getElementById("username").value;
            var password = document.getElementById("password").value;

            if (username === "" || password === "") {
                alert("Both username and password are required");
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
    
    <!-- Navbar -->
<nav class="navbar navbar-expand-lg topNav">
  <div class="container-fluid topNav ">
  <a class="navbar-brand" href="index.php">Queue Ease</a>
    </div>
  </div>
</nav>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4 login-container">
            <h2 class="text-center mb-4"><i class="fas fa-sign-in-alt"></i> Login</h2>

            <?php
                    if (!empty($error_message)) {
                        echo '<div class="alert alert-danger">' . $error_message . '</div>';
                    }
                    ?>
            <form action="login.php" method="post" onsubmit="return validateForm()">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Username:</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Password:</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block" style="width:100%;"> Login</button>
            </form>
            <a href="cashier_login.php"><i class="fas fa-cash-register"></i> Cashier</a>
        </div>
    </div>
</div>

</body>
</html>
