<?php
// Include database connection file
include_once 'db_connection.php';

// Query to fetch the next customer from the database, considering both priority and regular queues
$sql = "SELECT * FROM (SELECT * FROM priority_queue WHERE status = 'pending' UNION ALL SELECT * FROM regular_queue WHERE status = 'pending') AS combined_queue ORDER BY queue_number ASC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch customer data
    $customerData = $result->fetch_assoc();

    // Output customer data as JSON
    header('Content-Type: application/json');
    echo json_encode($customerData);
} else {
    // No pending customers
    $response = array('message' => 'No pending customers');
    header('Content-Type: application/json');
    echo json_encode($response);
}

// Close database connection
$conn->close();
?>
