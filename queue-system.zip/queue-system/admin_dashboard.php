<?php
session_start();
include 'db_connection.php';

$currentDate = date("Y-m-d");

// Get the total customers served from the regular queue
$sqlServedRegular = "SELECT COUNT(*) as totalServed FROM regular_queue WHERE status = 'served' AND DATE(queue_time) = '$currentDate'";
$resultServedRegular = $conn->query($sqlServedRegular);
$rowServedRegular = $resultServedRegular->fetch_assoc();
$totalServedRegular = $rowServedRegular['totalServed'];

// Get the total customers served from the priority queue
$sqlServedPriority = "SELECT COUNT(*) as totalServed FROM priority_queue WHERE status = 'served' AND DATE(queue_time) = '$currentDate'";
$resultServedPriority = $conn->query($sqlServedPriority);
$rowServedPriority = $resultServedPriority->fetch_assoc();
$totalServedPriority = $rowServedPriority['totalServed'];

// Get the total customers in regular queue for today
$sqlPendingRegular = "SELECT COUNT(*) as totalPending FROM regular_queue WHERE status = 'pending' AND DATE(queue_time) = '$currentDate'";
$resultPendingRegular = $conn->query($sqlPendingRegular);
$rowPendingRegular = $resultPendingRegular->fetch_assoc();
$totalPendingRegular = $rowPendingRegular['totalPending'];

// Get the total customers in priority queue for today
$sqlPendingPriority = "SELECT COUNT(*) as totalPending FROM priority_queue WHERE status = 'pending' AND DATE(queue_time) = '$currentDate'";
$resultPendingPriority = $conn->query($sqlPendingPriority);
$rowPendingPriority = $resultPendingPriority->fetch_assoc();
$totalPendingPriority = $rowPendingPriority['totalPending'];

// Calculate the total no-shows for the day from the regular queue
$sqlNoShowRegular = "SELECT COUNT(*) as totalNoShow FROM regular_queue WHERE status = 'No Show' AND DATE(queue_time) = '$currentDate'";
$resultNoShowRegular = $conn->query($sqlNoShowRegular);
$rowNoShowRegular = $resultNoShowRegular->fetch_assoc();
$totalNoShowRegular = $rowNoShowRegular['totalNoShow'];

// Calculate the total no-shows for the day from the priority queue
$sqlNoShowPriority = "SELECT COUNT(*) as totalNoShow FROM priority_queue WHERE status = 'No Show' AND DATE(queue_time) = '$currentDate'";
$resultNoShowPriority = $conn->query($sqlNoShowPriority);
$rowNoShowPriority = $resultNoShowPriority->fetch_assoc();
$totalNoShowPriority = $rowNoShowPriority['totalNoShow'];

// Combine total served and pending customers
$totalServed = $totalServedRegular + $totalServedPriority;
$totalPending = $totalPendingRegular + $totalPendingPriority;
$totalNoShow = $totalNoShowRegular + $totalNoShowPriority;

// Get peak hours from regular queue
$sqlPeakHoursRegular = "SELECT DATE_FORMAT(queue_time, '%h:%i %p') as startHour, DATE_FORMAT(queue_time + INTERVAL 1 HOUR, '%h:%i %p') as endHour, COUNT(*) as peakHourCount 
                 FROM regular_queue 
                 GROUP BY startHour, endHour 
                 ORDER BY peakHourCount DESC LIMIT 1";
$resultPeakHoursRegular = $conn->query($sqlPeakHoursRegular);

// Get peak hours from priority queue
$sqlPeakHoursPriority = "SELECT DATE_FORMAT(queue_time, '%h:%i %p') as startHour, DATE_FORMAT(queue_time + INTERVAL 1 HOUR, '%h:%i %p') as endHour, COUNT(*) as peakHourCount 
                 FROM priority_queue 
                 GROUP BY startHour, endHour 
                 ORDER BY peakHourCount DESC LIMIT 1";
$resultPeakHoursPriority = $conn->query($sqlPeakHoursPriority);

// Initialize peak hours
$peakHour = '';

// Determine peak hour from regular queue
if ($resultPeakHoursRegular && $resultPeakHoursRegular->num_rows > 0) {
    $rowPeakHoursRegular = $resultPeakHoursRegular->fetch_assoc();
    $startHourRegular = $rowPeakHoursRegular['startHour'];
    $endHourRegular = $rowPeakHoursRegular['endHour'];
    $peakHourRegular = $startHourRegular . ' - ' . $endHourRegular;
}

// Determine peak hour from priority queue
if ($resultPeakHoursPriority && $resultPeakHoursPriority->num_rows > 0) {
    $rowPeakHoursPriority = $resultPeakHoursPriority->fetch_assoc();
    $startHourPriority = $rowPeakHoursPriority['startHour'];
    $endHourPriority = $rowPeakHoursPriority['endHour'];
    $peakHourPriority = $startHourPriority . ' - ' . $endHourPriority;
}

// Get missed queues from regular queue
$sqlMissedQueuesRegular = "SELECT COUNT(*) as missedQueues FROM regular_queue WHERE status = 'no show'";
$resultMissedQueuesRegular = $conn->query($sqlMissedQueuesRegular);
$rowMissedQueuesRegular = $resultMissedQueuesRegular->fetch_assoc();
$missedQueuesRegular = $rowMissedQueuesRegular['missedQueues'];

// Get missed queues from priority queue
$sqlMissedQueuesPriority = "SELECT COUNT(*) as missedQueues FROM priority_queue WHERE status = 'no show'";
$resultMissedQueuesPriority = $conn->query($sqlMissedQueuesPriority);
$rowMissedQueuesPriority = $resultMissedQueuesPriority->fetch_assoc();
$missedQueuesPriority = $rowMissedQueuesPriority['missedQueues'];

// Combine missed queues
$missedQueues = $missedQueuesRegular + $missedQueuesPriority;

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="admin2.css">
    <link rel="icon" href="sdcafafa.jpg">

    <style>
        /* Add this to your existing CSS or create a new section */
        .title-card {
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

      .metrics {
            display: flex;
            flex-direction: row;
            flex-wrap:wrap;
        }
        
        @media (max-width:940px){
         .metrics {
                display: flex;
                flex-direction:column;
                justify-content:center;
                align-items:center;
                height:100%;
            }
        }

        

        .metric {
            background-color: #f2f2f2f2; /* Adjusted to lighter shade for contrast */
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            width: 100%;
            max-width: 250px;
            margin: 10px;
            flex-grow: 1;
        }
              .title-card {
            background-color: #fff; /* Adjusted to lighter shade for contrast */
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 100%;
            max-width: 900px;
        }

        .metric-icon {
            font-size: 2.5rem;
            color: white;
            margin-bottom: 10px;
        }

        .metric h3, .metric h5 {
            font-size: 1.2rem;
            color: #fff; /* Adjust text color for better readability */
        }

        .metric p {
            font-size: 1.5rem;
            color: #fff; /* Adjust text color for better readability */
    
        }
         .mt-queue{
            background-color: #D89216;
            

        }
        .mt-show{
            background-color: #CD0B0B;

        }
        .mt-served{
            background-color: #4E9F3D;

        }
                /* Add this to your existing CSS or create a new section */
        .welcome-container {
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }

        .welcome-header {
            font-size: 28px;
            color: #333; /* Adjust text color as needed */
        }

        .welcome-text {
            font-size: 18px;
            color: #555; /* Adjust text color as needed */
        }
    

    </style>
<title>Admin Dashboard</title>
</head>
<body>

<?php include 'admin_navbar.php'; ?>
<main class="main-content">
    <?php
    if (isset($_SESSION["username"])) {
        echo "<div class='welcome-container'>";
        echo "<h2 class='welcome-header'>Welcome, " . $_SESSION["username"] . "!</h2>";
        echo "<p class='welcome-text'>Here is today's brief overview of data for the queue.</p>";
        // Add admin-specific content here
        echo "</div>";
    } else {
        // Use JavaScript to redirect to login page
        echo "<script>window.location.href = 'admin_dashboard.php';</script>";
        exit;
    }
    ?>
</main>

<div class="container-fluid animate-from-bottom ">
        <div class="main-container  d-flex justify-content-center align-items-center">
            <div class="title-card">
                <div class="metrics">
                    <div class="metric mt-served">
                        <i class="fas fa-users metric-icon"></i>
                        <div class="metric-content">
                            <h3>Served Customers</h3>
                            <p><b><?php echo $totalServed; ?></b></p>
                        </div>
                    </div>
                    <div class="metric mt-show">
                        <i class="fas fa-user-friends metric-icon"></i>
                        <div class="metric-content">
                            <h5>No Shows</h5>
                            <p><b><?php echo $totalNoShow; ?></b></p>
                        </div>
                    </div>
                    <div class="metric mt-queue">
                        <i class="fas fa-user-clock metric-icon"></i>
                        <div class="metric-content">
                            <h3>Customers in Queue</h3>
                            <p><b><?php echo $totalPending; ?></b></p>
                        </div>
                    </div>
                    <div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<script>
// Function to log out the user when the browser or tab is closed
function autoLogout() {
    // Make an AJAX request to the server to log out the user
    $.ajax({
        url: 'logout.php', // URL to the logout script
        method: 'POST',
        success: function() {
            // Optionally, you can perform any other actions here if needed
            console.log('Logged out successfully');
        }
    });
}

// Attach the autoLogout function to the 'beforeunload' event
window.onbeforeunload = function() {
    autoLogout();
};
</script>

</body>
</html>

