<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selectedDate'])) {
    // Get the selected date from the POST data
    $selectedDate = $_POST['selectedDate'];

    // If selectedDate is empty, return an empty JSON response
    if (empty($selectedDate)) {
        header('Content-Type: application/json');
        echo json_encode([]);
        exit();
    }

    // Query to fetch data from both priority_queue and regular_queue based on the selected date
    $sql = "SELECT q.*, c.name AS cashier_name, 
                   TIMESTAMPDIFF(SECOND, q.start_service_time, q.end_service_time) AS service_time
            FROM (
                SELECT * FROM priority_queue WHERE DATE(queue_time) = ?
                UNION ALL
                SELECT * FROM regular_queue WHERE DATE(queue_time) = ?
            ) AS q
            LEFT JOIN cashier AS c ON q.cashierid = c.id
            ORDER BY FIELD(q.service_type, 'priority', 'regular'), q.queue_time";

    // Prepare the statement
    $stmt = $conn->prepare($sql);

    // Bind the parameters
    $stmt->bind_param("ss", $selectedDate, $selectedDate);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    $data = []; // Array to store the fetched data

    // Function to format seconds into "X hours, Y minutes, Z seconds"
    function formatTime($seconds) {
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $seconds = $seconds % 60;
        $formattedTime = '';
        if ($hours > 0) {
            $formattedTime .= $hours . ' hours, ';
        }
        if ($minutes > 0) {
            $formattedTime .= $minutes . ' minutes, ';
        }
        $formattedTime .= $seconds . ' seconds';
        return $formattedTime;
    }

    // Fetch the data
    while ($row = $result->fetch_assoc()) {
        // Format service time in "X hours, Y minutes, Z seconds" if available
        $serviceTime = !is_null($row['service_time']) ? formatTime($row['service_time']) : 'N/A';
        
        // Create a new associative array with specified keys and values from the result set
        $data[] = [
            'name' => $row['name'],
            'student_number' => $row['student_number'],
            'service_type' => $row['service_type'],
            'payment_for' => $row['payment_for'],
            'payment_mode' => $row['payment_mode'],
            'email' => $row['email'],
            'queue_number' => $row['queue_number'],
            'queue_time' => $row['queue_time'],
            'status' => $row['status'],
            'cashier_name' => $row['cashier_name'],
            'average_service_time' => $serviceTime
        ];
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();

    // Return the data as JSON
    header('Content-Type: application/json');
    echo json_encode($data);
} else {
    // Handle invalid or missing parameters
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request']);
}
?>
