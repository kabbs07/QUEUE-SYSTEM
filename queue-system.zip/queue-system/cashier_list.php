<?php
session_start();

// Include your database connection file
include_once 'db_connection.php'; // Update this line with your actual connection file

// Define the number of entries per page
$entriesPerPage = 5;

// Determine the current page number
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;

// Calculate the offset for the SQL query
$offset = ($current_page - 1) * $entriesPerPage;

// Fetch cashier data with pagination from the database
$sql = "SELECT * FROM cashier LIMIT $offset, $entriesPerPage";
$result = $conn->query($sql);

// Fetch total number of rows for pagination
$totalRowsSql = "SELECT COUNT(*) as count FROM cashier";
$totalRowsResult = $conn->query($totalRowsSql);
$totalRows = $totalRowsResult->fetch_assoc()['count'];

// Calculate total number of pages
$totalPages = ceil($totalRows / $entriesPerPage);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="admin2.css">
    <title>Admin Dashboard</title>
    <link rel="icon" href="sdcafafa.jpg">

</head>
<body>

<?php include 'admin_navbar.php'?>

<div class="container mt-4">
    <form class="d-flex justify-content-between align-items-center mb-3">
        <h2>Cashier List</h2>
        <button type="button" class="btn btn-primary" id="addUserButton"><i class="fa fa-plus"></i> Add New</button>
    </form>

    <table class="table table-striped table-bordered table-hover" id="cashierTable">
        <thead class="thead-secondary">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Log Status</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $counter = ($current_page - 1) * $entriesPerPage + 1;
                while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $counter . '</td>';
                echo '<td>' . $row['name'] . '</td>';
                echo '<td>' . ($row['log_status'] == 1 ? 'In Use' : 'Not In Use') . '</td>';
                echo '<td>' . ucfirst(strtolower($row['status'])) . '</td>';
                echo '<td class="text-center">';
                echo '<button type="button" class="btn btn-info mr-2" onclick="editCashier(' . $row['id'] . ', \'' . $row['name'] . '\', \'' . $row['status'] . '\')"><i class="fa fa-cogs"></i> Edit</button>';
                echo '<button type="button" class="btn btn-danger" onclick="deleteCashier(' . $row['id'] . ')"><i class="fa fa-trash"></i> Delete</button>';
                echo '</td>';
                echo '</tr>';
                $counter++;
            }
            ?>
        </tbody>
    </table>
   
   <?php
    echo '<nav aria-label="Page navigation">';
    echo '<ul class="pagination justify-content-center">';

    if ($current_page > 1) {
        echo '<li class="page-item"><a class="page-link" href="?page=' . ($current_page - 1) . '" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>';
    } else {
        echo '<li class="page-item disabled"><span class="page-link" aria-hidden="true">&laquo;</span></li>';
    }

    for ($i = 1; $i <= $totalPages; $i++) {
        echo '<li class="page-item ' . ($i == $current_page ? 'active' : '') . '"><a class="page-link" href="?page=' . $i . '">' . $i . '</a></li>';
    }

    if ($current_page < $totalPages) {
        echo '<li class="page-item"><a class="page-link" href="?page=' . ($current_page + 1) . '" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>';
    } else {
        echo '<li class="page-item disabled"><span class="page-link" aria-hidden="true">&raquo;</span></li>';
    }

    echo '</ul>';
    echo '</nav>';
    ?>

<!-- Edit Cashier Modal -->
<div class="modal fade" id="editCashierModal" tabindex="-1" role="dialog" aria-labelledby="editCashierModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editCashierModalLabel">Edit Cashier Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="editCashierForm" method="post" action="update_cashier.php" onsubmit="return confirm('Are you sure you want to save changes?')">
                    <input type="hidden" id="editCashierId" name="editCashierId" value="">
                    <div class="form-group">
                        <label for="editName">Name:</label>
                        <input type="text" id="editName" name="editName" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="editPassword">Password:</label>
                        <input type="password" id="editPassword" name="editPassword" class="form-control" placeholder="Leave blank to keep current password">
                    </div>
                    <div class="form-group">
                        <label for="editStatus">Status:</label>
                        <select id="editStatus" name="editStatus" class="form-control">
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Add New Cashier</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="add_user.php" onsubmit="return confirm('Are you sure you want to add this user?')">
                    <div class="form-group">
                        <label for="newName">Name:</label>
                        <input type="text" id="newName" name="newName" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="newPassword">Password:</label>
                        <input type="password" id="newPassword" name="newPassword" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="newStatus">Status:</label>
                        <select id="newStatus" name="newStatus" class="form-control" required disabled>
                            <option value="Active" selected>Active</option>
                        </select>
                        <!-- Hidden input to submit the value -->
                        <input type="hidden" name="newStatus" value="Inactive">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<script>
    function showAddUserModal() {
        $('#addUserModal').modal('show');
    }

    document.getElementById('addUserButton').addEventListener('click', showAddUserModal);

    function deleteCashier(id) {
        if (confirm('Are you sure you want to delete this cashier?')) {
            $.post('delete_cashier.php', {id: id}, function(response) {
                if (response === 'success') {
                    location.reload();
                } else {
                    alert('Error deleting cashier: ' + response);
                }
            });
        }
    }

    function editCashier(id, name, status) {
        $("#editCashierId").val(id);
        $("#editName").val(name);
        $("#editStatus").val(status);
        $("#editCashierModal").modal("show");
    }

    function saveChanges() {
        var id = $("#editCashierId").val();
        var name = $("#editName").val();
        var status = $("#editStatus").val();

        $.ajax({
            type: "POST",
            url: "update_cashier.php",
            data: {
                editCashierId: id,
                editName: name,
                editStatus: status
            },
            success: function(response) {
                if (response === 'success') {
                    location.reload();
                } else {
                    alert('Error updating cashier: ' + response);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error: ' + status + ' - ' + error);
            }
        });

        $("#editCashierModal").modal("hide");
    }

    $("#saveChangesButton").click(saveChanges);
</script>

</body>
</html>
<?php
$conn->close();
?>
