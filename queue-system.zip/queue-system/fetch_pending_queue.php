<?php
include_once 'db_connection.php';

// Fetch pending queue numbers
$PriorityPendingSql = "SELECT queue_number FROM priority_queue WHERE status = 'pending' ORDER BY queue_number ASC";
$PriorityResult = $conn->query($PriorityPendingSql);

$data = array();
if ($PriorityResult->num_rows > 0) {
    while ($row = $PriorityResult->fetch_assoc()) {
        $data[] = $row;
    }
}

// Fetch pending queue numbers
$RegularPendingSql = "SELECT queue_number FROM regular_queue WHERE status = 'pending' ORDER BY queue_number ASC";
$RegularResult = $conn->query($RegularPendingSql);

if ($RegularResult->num_rows > 0) {
    while ($row = $RegularResult->fetch_assoc()) {
        $data[] = $row;
    }
}

echo json_encode($data);

$conn->close();
?>
