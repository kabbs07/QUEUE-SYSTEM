<?php
include_once 'db_connection.php';

// Initialize an array to hold the response
$response = [];

// Fetch cashier ID from POST data
$cashierId = $_POST['cashier_id'] ?? null;

if ($cashierId === null) {
    // If no cashier ID is provided, return an error message
    $response['error'] = "Cashier ID is not provided.";
    echo json_encode($response);
    exit();
}

// Function to handle fetching and updating the next pending customer
function fetch_and_update_next_pending_customer($queue_table, $cashierId, &$response, $conn) {
    // Fetch the next pending customer from the specified queue table
    $sql = "SELECT id, name, student_number, service_type, payment_for, payment_mode, email, queue_number 
            FROM $queue_table 
            WHERE status = 'pending' 
            ORDER BY queue_number ASC 
            LIMIT 1";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Add the row to the response
        $response[] = $row;

        // Fetch the customer ID
        $customerId = $row['id'];

        // Update the status of the customer to 'serving' and set the cashier ID
        // Also set start_service_time to the current timestamp
        $currentTime = date('Y-m-d H:i:s');
        $updateSql = "UPDATE $queue_table 
                      SET status = 'serving', cashierid = ?, start_service_time = ? 
                      WHERE id = ?";
        $stmt = $conn->prepare($updateSql);
        $stmt->bind_param("isi", $cashierId, $currentTime, $customerId);

        if (!$stmt->execute()) {
            // If the update fails, add an error message to the response
            $response['error'] = "Error updating record: " . $stmt->error;
        }

        // Add functions to mark the customer as served or no show, if triggered by an external event
        if (isset($_POST['trigger_update_served']) && $_POST['trigger_update_served'] === 'true') {
            $updateStatusSql = "UPDATE $queue_table SET status = 'served' WHERE id = ?";
            $stmtUpdate = $conn->prepare($updateStatusSql);
            $stmtUpdate->bind_param("i", $customerId);

            if (!$stmtUpdate->execute()) {
                $response['error'] = "Error updating status to 'served': " . $stmtUpdate->error;
            }
        }

        if (isset($_POST['trigger_update_no_show']) && $_POST['trigger_update_no_show'] === 'true') {
            $updateStatusSql = "UPDATE $queue_table SET status = 'no show' WHERE id = ?";
            $stmtUpdate = $conn->prepare($updateStatusSql);
            $stmtUpdate->bind_param("i", $customerId);

            if (!$stmtUpdate->execute()) {
                $response['error'] = "Error updating status to 'no show': " . $stmtUpdate->error;
            }
        }
        return true;
    }
    return false;
}

// Check and update the priority queue first
$priorityQueueUpdated = fetch_and_update_next_pending_customer('priority_queue', $cashierId, $response, $conn);

if (!$priorityQueueUpdated) {
    // If there are no pending customers in the priority queue or if a customer was served
    // check the regular queue
    fetch_and_update_next_pending_customer('regular_queue', $cashierId, $response, $conn);
}

// Close the database connection
$conn->close();

// Encode and return the response as JSON
echo json_encode($response);
?>
