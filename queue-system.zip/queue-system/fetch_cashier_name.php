<?php
include_once 'db_connection.php';

// Get the cashier ID from the query parameters
$cashierId = $_GET['cashier_id'] ?? null;

// Set header to indicate the response type as JSON
header('Content-Type: application/json');

if ($cashierId !== null) {
    // Fetch the cashier's name based on the cashier ID
    $sql = "SELECT name FROM cashier WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $cashierId);
    $stmt->execute();

    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $cashierName = $row['name'];
        
        // Return the cashier's name as JSON
        echo json_encode(['name' => $cashierName]);
    } else {
        // No cashier found with the given ID
        echo json_encode(['error' => 'Cashier not found']);
    }

    $stmt->close();
} else {
    // Missing cashier ID
    echo json_encode(['error' => 'Missing cashier ID']);
}

// Close the database connection
$conn->close();

