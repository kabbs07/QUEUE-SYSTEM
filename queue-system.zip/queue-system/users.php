<?php
session_start();

// Include your database connection file
include_once 'db_connection.php';

// Initialize variables for messages and errors
$error_message = "";
$success_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the form data and insert into the database

    // Get form data
    $name = isset($_POST['newName']) ? $_POST['newName'] : "";
    $username = isset($_POST['newUsername']) ? $_POST['newUsername'] : "";
    $password = isset($_POST['newPassword']) ? password_hash($_POST['newPassword'], PASSWORD_DEFAULT) : ""; // Hash the password for security

    // Check if the username already exists
    $check_username_query = "SELECT * FROM userss WHERE username = '$username'";
    $check_username_result = $conn->query($check_username_query);

    if ($check_username_result->num_rows > 0) {
        $error_message = "Username '$username' already exists. Please choose a different username.";
    } else {
        // Insert data into the database
        $sql = "INSERT INTO userss (name, username, password) VALUES ('$name', '$username', '$password')";

        if ($conn->query($sql) === TRUE) {
            $success_message = "User added successfully!";
        } else {
            $error_message = "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Close the database connection
$conn->close();

// Output success or error message
if (!empty($success_message)) {
    echo '<p style="color: green;">' . $success_message . '</p>';
} elseif (!empty($error_message)) {
    echo '<p style="color: red;">' . $error_message . '</p>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="admin2.css">
    <link rel="icon" href="sdcafafa.jpg">


    <title>Admin Dashboard</title>
    <script>
function confirmDelete(userId) {
    var confirmDelete = confirm("Are you sure you want to delete this user?");
    if (confirmDelete) {
        window.location.href = 'delete_user.php?user_id=' + userId;
    }
}

</script>
</head>
<body>

<?php include 'admin_navbar.php'?>
<?php
include 'db_connection.php';

$entriesPerPage = 5;

// Fetch data from the database
$sql = "SELECT * FROM userss";
$result = $conn->query($sql);

// Calculate the total number of pages
$totalPages = ceil($result->num_rows / $entriesPerPage);

// Get the current page number from the query string, default to 1
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;

// Calculate the offset for the SQL query
$offset = ($current_page - 1) * $entriesPerPage;

// Modify your SQL query to include the LIMIT clause
$sql = "SELECT * FROM userss LIMIT $offset, $entriesPerPage";
$result = $conn->query($sql);

if ($result !== false && $result->num_rows > 0) {
    // Output the "Add User" button
    echo '<div class="container mt-4">';
    echo '<div class="d-flex justify-content-between align-items-center mb-3">';
    echo '<h2>User Management</h2>';
    echo '<button class="btn btn-primary" data-toggle="modal" data-target="#addUserModal"><i class="fa fa-plus"></i> Add User</button>';
    echo '</div>';
    echo '<div class="table-responsive">';
    echo '<table class="table table-striped table-bordered table-hover">';
    echo '<thead class="thead-secondary">';
    echo '<tr><th>ID</th><th>Name</th><th>Username</th><th>Action</th></tr>';
    echo '</thead>';
    echo '<tbody>';

    $rowNumber = 1; // Initialize row number

    while ($row = $result->fetch_assoc()) {
        echo '<tr>'; // Start a new row for each record
        echo "<td><strong>" . $rowNumber . "</strong></td>"; // Make the row number bold
        echo "<td>" . $row["name"] . "</td>";
        echo "<td>" . $row["username"] . "</td>";
        echo '<td class="text-center">'; 
        echo '<div class="btn-group">';
        echo '<button class="btn btn-info dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">';
        echo '<i class="fa fa-cogs"></i> Edit';
        echo '</button>';
        echo '<div class="dropdown-menu">';
        echo '<a class="dropdown-item" href="#" data-toggle="modal" data-target="#manageUserModal' . $rowNumber . '"><i class="fa fa-user"></i> Manage User</a>';
        echo '<a class="dropdown-item" href="javascript:void(0);" onclick="confirmDelete(' . $row["id"] . ')"><i class="fa fa-trash"></i> Delete</a>';
        echo '</div>';
        echo '</div>';
        echo '</td>'; // Action column with dropdown
        echo '</tr>'; // End the row

        // Modal for managing user
        echo '<div class="modal fade" id="manageUserModal' . $rowNumber . '" tabindex="-1" role="dialog" aria-labelledby="manageUserModalLabel' . $rowNumber . '" aria-hidden="true">';
        echo '<div class="modal-dialog" role="document">';
        echo '<div class="modal-content">';
        echo '<div class="modal-header">';
        echo '<h5 class="modal-title" id="manageUserModalLabel' . $rowNumber . '"><i class="fa fa-user"></i> Manage User: ' . $row["username"] . '</h5>';
        echo '<button type="button" class="close" data-dismiss="modal" aria-label="Close">';
        echo '<span aria-hidden="true">&times;</span>';
        echo '</button>';
        echo '</div>';
        echo '<div class="modal-body">';
        // Add your form inputs for managing the user here

        // Retrieve existing user details
        $user_id = $row["id"];
        $sql_user_details = "SELECT * FROM userss WHERE id = $user_id";
        $result_user_details = $conn->query($sql_user_details);

        if ($result_user_details->num_rows > 0) {
            $user_details = $result_user_details->fetch_assoc();

            echo '<form method="post" action="update_user.php" onsubmit="return confirm(\'Are you sure you want to save changes?\')">';
            echo '<input type="hidden" name="userId" value="' . $user_details["id"] . '">';
            echo '<div class="form-group">';
            echo '<label for="newUsername"><i class="fa fa-user"></i> New Username:</label>';
            echo '<input type="text" id="newUsername" name="newUsername" class="form-control" value="' . $user_details["username"] . '">';
            echo '</div>';
            echo '<div class="form-group">';
            echo '<label for="newPassword"><i class="fa fa-lock"></i> New Password:</label>';
            echo '<input type="password" id="newPassword" name="newPassword" class="form-control" required>';
            echo '</div>';
            echo '<button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save Changes</button>';
            echo '</form>';
        } else {
            echo '<p>Error retrieving user details.</p>';
        }

        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';




  

        $rowNumber++; // Increment row number
    }

    echo '</tbody>';
    echo '</table>';
    echo '</div>';


    // Add User Modal
    echo '<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel" aria-hidden="true">';
    echo '<div class="modal-dialog" role="document">';
    echo '<div class="modal-content">';
    echo '<div class="modal-header">';
    echo '<h5 class="modal-title" id="addUserModalLabel"><i class="fa fa-plus"></i> Add New User</h5>';
    echo '<button type="button" class="close" data-dismiss="modal" aria-label="Close">';
    echo '<span aria-hidden="true">&times;</span>';
    echo '</button>';
    echo '</div>';
    echo '<div class="modal-body">';
    // Add your form inputs for adding a new user here
    echo '<form method="post" action="">';
    echo '<div class="form-group">';
    echo '<label for="newName"><i class="fa fa-user"></i> Name:</label>';
    echo '<input type="text" id="newName" name="newName" class="form-control" required>';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<label for="newUsername"><i class="fa fa-user"></i> Username:</label>';
    echo '<input type="text" id="newUsername" name="newUsername" class="form-control" required>';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<label for="newPassword"><i class="fa fa-lock"></i> Password:</label>';
    echo '<input type="password" id="newPassword" name="newPassword" class="form-control" required>';
    echo '</div>';
    echo '<button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-save"></i> Add User</button>';
    echo '</form>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';

      

// Pagination
echo '<nav aria-label="Page navigation">';
echo '<ul class="pagination justify-content-center">';

// Previous Page
if ($current_page > 1) {
    echo '<li class="page-item"><a class="page-link" href="?page=' . ($current_page - 1) . '" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>';
} else {
    echo '<li class="page-item disabled"><span class="page-link" aria-hidden="true">&laquo;</span></li>';
}

// Page numbers
for ($i = 1; $i <= $totalPages; $i++) {
    echo '<li class="page-item ' . ($i == $current_page ? 'active' : '') . '"><a class="page-link" href="?page=' . $i . '">' . $i . '</a></li>';
}

// Next Page
if ($current_page < $totalPages) {
    echo '<li class="page-item"><a class="page-link" href="?page=' . ($current_page + 1) . '" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>';
} else {
    echo '<li class="page-item disabled"><span class="page-link" aria-hidden="true">&raquo;</span></li>';
}

echo '</ul>';
echo '</nav>';


    } 
    else {
        echo '<p class="text-center mt-4" style="font-size: 18px; color: #555;">No records found.</p>';
    }

$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>
