<?php
include 'db_connection.php';

// Query to retrieve data from the database (replace with your actual query)
$sql = "SELECT id, label FROM transaction_options";
$result = $mysqli->query($sql);

$data = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Close the database connection
$mysqli->close();

// Return the data as JSON
echo json_encode($data);
?>
