<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap4.min.css"> <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.0/css/buttons.dataTables.min.css"> <!-- DataTables Buttons CSS -->
    <link rel="stylesheet" href="admin2.css">
    <link rel="icon" href="sdcafafa.jpg">

    <title>Admin Dashboard</title>
    <style>
        /* Add custom styles here */
        body {
            background-color: #f8f9fa;
        }

        .container {
            margin-top: 20px;
        }

        h2 {
            color: black;
        }

        .table-filter-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .date-filter-form {
            max-width: 200px;
            margin-left: auto;
        }

        .date-filter-form input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .date-filter-form button {
            display: block;
            width: 100%;
            padding: 7px;
            background-color: #CD0B0B;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>

<body>

    <?php include 'admin_navbar.php'; ?>

    <div class="container">
        <h2 class="mb-4">Customer Details</h2>

        <div class="table-filter-container">
            <div class="date-filter-form">
                <label for="selectedDate">Filter by Date:</label>
                <form id="dateFilterForm" method="post">
                    <div class="input-group">
                        <input type="date" class="form-control" id="selectedDate" name="selectedDate">
                        <div class="input-group-append">
                            <button class="btn btn-primary btn-filter" type="button" onclick="applyDateFilter()">Apply</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="table-responsive">
            <table id="customerDetailsTable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Student Number</th>
                        <th>Service Type</th>
                        <th>Payment For</th>
                        <th>Payment Mode</th>
                        <th>Email</th>
                        <th>Queue Number</th>
                        <th>Queue Time</th>
                        <th>Status</th>
                        <th>Cashier Name</th>
                        <th>Average Service Time</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.0/js/buttons.html5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>


    <script>
$(document).ready(function() {
    // Initialize the DataTable
    var table = $('#customerDetailsTable').DataTable({
        columns: [
            { data: 'name', title: 'Name' },
            { data: 'student_number', title: 'Student Number' },
            { data: 'service_type', title: 'Service Type' },
            { data: 'payment_for', title: 'Payment For' },
            { data: 'payment_mode', title: 'Payment Mode' },
            { data: 'email', title: 'Email' },
            { data: 'queue_number', title: 'Queue Number' },
            { 
                data: 'queue_time', 
                title: 'Queue Time',
                render: function(data) {
                    return moment(data).format('MMMM D, YYYY h:mm A');
                }
            },
            { data: 'status', title: 'Status' },
            { data: 'cashier_name', title: 'Cashier Name' },
            { data: 'average_service_time', title: 'Average Service Time' }
        ],
        pageLength: 10, // Number of rows per page
        lengthMenu: [10, 25, 50, 100], // Options for rows per page
        order: [[7, 'asc']], // Default sorting by 'Queue Time'
        dom: 'lBftip', // Configure layout
        buttons: [
            'copy', 'csv'
        ]
    });

    // Apply date filter to DataTable
    function applyDateFilter() {
        var selectedDate = $('#selectedDate').val();

        // Check if a date is selected
        if (!selectedDate) {
            // Clear the DataTable if no date is selected
            table.clear().draw();
            return;
        }

        // Fetch data using AJAX if a date is selected
        $.ajax({
            url: 'filter_data.php',
            method: 'POST',
            data: { selectedDate: selectedDate },
            success: function(data) {
                // Clear existing data and add new rows to the DataTable
                table.clear().rows.add(data).draw();
            },
            error: function(xhr, status, error) {
                console.error("AJAX error:", xhr.responseText);
            }
        });
    }

    // Attach applyDateFilter function to the "Apply" button
    $('#dateFilterForm .btn-filter').on('click', applyDateFilter);
});

    </script>
</body>
</html>
