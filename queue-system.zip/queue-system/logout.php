<?php
session_start();

// Update the log_status to 'not in use' for the cashier in the database
if (isset($_SESSION['cashier_id'])) {
    include_once 'db_connection.php';
    $cashierId = $_SESSION['cashier_id'];

    // Update the log_status to 'not in use'
    $sql = "UPDATE cashier SET log_status = 0 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $cashierId);
    $stmt->execute();
    $stmt->close();
}

// Destroy the session
session_unset();
session_destroy();

// If it's an AJAX request, you don't need to redirect
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Send a success response to the client
    echo json_encode(['status' => 'success']);
    exit();
}

// If it's not an AJAX request, redirect to the login page
header("Location: login.php");
exit;
?>
